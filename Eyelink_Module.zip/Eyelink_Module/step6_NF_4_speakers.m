%% Sound presentation script for Neurofeedback (NF)Training
%
% This script presents audio  probes from different directions (speakers).
% The presentation is also synchronized with EEG and eye tracker.
%
% The direction of the probe presentation is randomized but equally
% distributed among the used speakers.
% The ISI (inter-stimulus interval) is also randomized by using a jitter
% from 3 to 4.5 seconds
%
% Important input variables are:
% - Subject ID (subj_id)
% - NF-session number (session_nr)
% - Nr. of speakers (n_directions)
% - Nr. of trials (n_trials)
% - Nr. of NF-block. Sessions are actually divided into four blocks of 100
% trials each.
% 
% The variables in the workspace are stored in a file named
% 'NF_XXX_session_nrY.mat', where XXX ist the Subject_id and Y is the
% session number
%
% History
% -------
% First version: 11.02.2023
%
% Contact
% -------
% Felix Stockar
%
% University of Zürich
% Department of Comparative Language Science

close all
clear
clc

trigger_port = config_io();      % Is necessary to send triggers to EEG
PsychPortAudio('Close')
HomeDIR                   = 'C:\Data\P31-Preisig\Exp5 Matlab';
DestinDIR                 = [HomeDIR, '\logfiles'];

prompt     = {'Date', 'Subject ID', 'Session Nr.', 'Block Nr.','Attenuation Level [dB]'};
dlg_title  = 'Neurofeedback';
d          = datetime('today');
defaultans = {datestr(d), 'Type a no.', 'Type a no.', 'Type a no.','-40'};
user_ans   = inputdlg(prompt, dlg_title, [1 45], defaultans, 'on');
subj_id    = user_ans{2, 1};
session_nr = user_ans {3, 1};
block_nr = user_ans {4, 1};
data_id    = ['NF_' user_ans{2, 1} '_S' user_ans{3, 1} '_B' block_nr];
attenuation_level = str2double(user_ans {5, 1});

% check if files already exist:   (just copy-paste this section to the AAT scripts)
cd(DestinDIR)
if isfile([data_id  '.mat'])
        h = msgbox(' File already exists', 'Warning', 'error');     % display warning
        posn = get(h, 'Position');
        waitfor(h)

        return;
else
   
end
% Remind user to select correct mixer settings:
        h = msgbox(' Select Mixer Settings: NF 4 spk', '');
        posn = get(h, 'Position');
        waitfor(h)

%% (1) Initialization
sf = 44100;
dur = 0.5;
t = 0:1/sf:dur-1/sf; % Time vector
% Parameters for the bell sound
fundamental_frequency = 440; % Frequency of the fundamental tone
num_harmonics = 10; % Number of harmonics to generate the bell-like sound
amplitudes = 1./[1:num_harmonics]; % Amplitudes of the harmonics
% Generate the bell-like sound
tone = zeros(size(t));
for harmonic = 1:num_harmonics
    tone = tone + amplitudes(harmonic) * sin(2 * pi * harmonic * fundamental_frequency * t);
end
% Normalize the sound
tone = tone / max(abs(tone));

% Play the sound
%sound(tone, sf);

% define cues
cue1(:, 1)  = tone;  % presentation from left channel
cue1(:, 2)  = 0;
cue1(:, 3)  = 0;
cue1(:, 4)  = 0;
cue1(:, 5)  = click; % add click to audio channel 4 (audio trigger)

cue2(:, 2)  = tone;  % presentation from center channel
cue2(:, 1)  = 0;  
cue2(:, 3)  = 0;
cue2(:, 4)  = 0;
cue2(:, 5)  = click;

cue3(:, 3)  = tone;  % presentation from right channel
cue3(:, 1)  = 0;  
cue3(:, 2)  = 0;  
cue3(:, 4)  = 0;
cue3(:, 5)  = click;

cue4(:, 4)  = tone;  % presentation from right channel
cue4(:, 1)  = 0;  
cue4(:, 2)  = 0;  
cue4(:, 3)  = 0;
cue4(:, 5)  = click;


% settings for NF-setup
n_trials=100;        % number of probes. Default: 100 probes / 4 Sessions
n_directions=4;      % number of used speakers

% set up TCP port
ip = '10.65.28.21';
port = 4012;
t = tcpclient(ip, port);  % set up client

% variables for TCP messaging
start_name = '!start';
nf_start = uint8(start_name);

stop_name = '!stop';
nf_stop = uint8(stop_name);

% calculate randomzed presentation sequence
rng(str2num(subj_id),'twister') % Reproducible randomization (input, e.g. participant ID) --> as "setseed" in R
presentation_seq=sort(repmat(1:n_directions,1,round(n_trials/n_directions)));
presentation_seq=presentation_seq(randperm(n_trials));
% define ISI parameters
isi_min     = 3.0;  % length according to Bagherzadeh (2020)
isi_max     = 4.5;
isi_mean    = (isi_min+isi_max)/2;
isi_sd      = 0.5;
                                            
total_isi_duration = isi_mean*(n_trials);           % total ISI duration
ISI = isi_mean + isi_sd * randn(1, n_trials);       % create ISI array with 100 (n_trials) entries from 3 to 4.5 sec 
current_total_duration = sum(ISI);
scale = total_isi_duration / current_total_duration;
ISI = ISI * scale;                                  % scale ISI values to total duration
ISI = min(max(ISI, 3), 4.5);                        % cut down if needed 
% sum(ISI)

%% (3) Set Up Sound Output
InitializePsychSound(1)
device_list  = PsychPortAudio('GetDevices'); 
snd_dev_index = find(strcmp({device_list.HostAudioAPIName}, 'Windows WASAPI') & strcmp({device_list.DeviceName}, 'Analog (1-8) (RME UFX II)') & ismember([device_list.NrOutputChannels], 8));
device_index = device_list(snd_dev_index).DeviceIndex; 
nrchannels = n_directions + 1; % number of used audio channels. The last channel is reserved for the audio trigger (click)
pahandle = PsychPortAudio('Open', device_index, 1, 3, sf, nrchannels);  % last parameter: select channel;                                                                                 
PsychPortAudio('Volume', pahandle, 0.25);    % Set overall volume

%% (4) Set up EyeLink
Eyelink('Shutdown')                                                                 % make sure tracker is shut down
Setup.Eyelink = EyelinkInitDefaults();                                              % get eyelink defaults and store in property 'el'
Setup.Eyelink.connection = Eyelink('IsConnected');                                  % get connection status and stor in property 'connection'
Eyelink('Initialize');                                                              % initialize regular mode

Eyelink('command','file_sample_data=LEFT,RIGHT,GAZE,AREA,GAZERES,STATUS');          % data types for gaze cursor pc
Eyelink('command','file_event_filter = LEFT,RIGHT,FIXATION,BLINK,MESSAGE,BUTTON');  % data types saved to edf files
Eyelink('command','link_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,BUTTON');  % data types sent to exeprimenter pc
Eyelink('command','link_sample_data  = LEFT,RIGHT,GAZE,GAZERES,AREA,STATUS');       % data types for gaze cursor;
Eyelink('command','pupil_size_diameter=DIAMETER');                                  % setting pupil diameter as the pupil size measurement
Eyelink('command','binocular_enabled=YES');                                         %  binocular tracking
Eyelink('command','active_eye=BINOCULAR');

[~,fs] = Eyelink('ReadFromTracker', 'sample_rate');                                 % read sampling rate and store in property
Setup.Eyelink.fs = str2double(fs);

cd(DestinDIR)
EyeLinkFileName = ['NFB' subj_id session_nr block_nr];

status = Eyelink('OpenFile',EyeLinkFileName);                                       % open file
if status~=0
    msgbox('Cannot create EDF file');                                               % if fail report back
    Screen('CloseAll');
end

Eyelink('startrecording');
WaitSecs(1);

%% Start EEG recording
write(t, nf_start); % start BEE Lab recording
WaitSecs(3);        % BEE Lab needs some time to start recording ...

%% (5) Main Presentation Loop


Eyelink('Message', ('REC100'));  % new message-strings according to Natalyias instructions

WaitSecs(1);                     % Countdown to first trial/trigger
SendTrig(trigger_port, 1)        % Send trigger to brain data recorder
WaitSecs(1);         
SendTrig(trigger_port, 1)      
WaitSecs(1);        
SendTrig(trigger_port, 1)

start_time = GetSecs;               
for i = 1:n_trials
    direction = presentation_seq(i);
    if         direction == 1
        cue = cue1;
    elseif     direction == 2
        cue = cue2;
    elseif     direction == 3
        cue = cue3;
    else
        cue = cue4;

    end

    PsychPortAudio('FillBuffer', pahandle, cue'); % Works only if your audio device has more than 2 output channels
    WaitSecs(ISI(i));
    Eyelink('Message', 'CUE128');
    fprintf(['       Trial ' num2str(i) '/' num2str(n_trials) ' ...\n'])
    fprintf(['       Direction ' num2str(direction) ' ...\n'])
    PsychPortAudio('Start', pahandle, 1, 0);
    WaitSecs(0.5); % wait for tone to play


end
elapsed_time = GetSecs - start_time;
fprintf(['   *** End of NF block ' num2str(block_nr) ' of 4'  '.\n']);

Eyelink('Message', 'END100');     % 'END' has the same value as 'REC' (start)

WaitSecs(1);                      % Countdown to end
SendTrig(trigger_port, 1)         % Send trigger to brain data recorder
WaitSecs(1);         
SendTrig(trigger_port, 1)      
WaitSecs(1);        
SendTrig(trigger_port, 1)
WaitSecs(1);

Eyelink('StopRecording');        % stop recording
Eyelink('SetOfflineMode');       % set to idle mode
Eyelink('CloseFile');            % close file
WaitSecs(1);                     % waiting for delay - important since data could be lost otherwise

write(t, nf_stop);               % stop EEG recording

% [status =] Eyelink('ReceiveFile',['filename'], ['dest'], ['dest_is_path'])
status=Eyelink('ReceiveFile', EyeLinkFileName, 'C:\Data\P31-Preisig\Exp5 Matlab\logfiles\', 1);

if status > 0
    disp(['   *** Transfer in Datei ', EyeLinkFileName, ' erfolgreich beendet.'])
elseif status == 0
    disp('   *** Transfer abgebrochen');
else
    disp(['   *** Fehler im Transfer: Status = ', num2str(status)])
end

cd(DestinDIR)
save(data_id)   % save MATLAB variables to logfile

PsychPortAudio('Close')

