function status = waitForCalibrationAcceptance()
    while true
        if Eyelink('command', 'IsCalibrated') == 1
            disp('Calibration accepted.');
            status = 'accepted';
            break;
        elseif Eyelink('command', 'IsCalibrated') == 0
            disp('Calibration rejected.');
            status = 'rejected';
            break;
        end
    end
end