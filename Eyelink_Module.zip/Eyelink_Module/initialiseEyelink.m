%% initialise eyetracker
Eyelink('Shutdown')                                                                 % make sure tracker is shut down
Setup.Eyelink = EyelinkInitDefaults();                                              % get eyelink defaults and store in property 'el'
Setup.Eyelink.connection = Eyelink('IsConnected');                                  % get connection status and stor in property 'connection'
% Eyelink('Initialize');                                                            % initialize regular mode
EyelinkInit;

Eyelink('command','file_sample_data=LEFT,RIGHT,GAZE,AREA,GAZERES,STATUS');          % data types for gaze cursor pc
Eyelink('command','file_event_filter = LEFT,RIGHT,FIXATION,BLINK,MESSAGE,BUTTON');  % data types saved to edf files
Eyelink('command','link_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,BUTTON');  % data types sent to exeprimenter pc
Eyelink('command','link_sample_data  = LEFT,RIGHT,GAZE,GAZERES,AREA,STATUS');       % data types for gaze cursor;
Eyelink('command','pupil_size_diameter=DIAMETER');                                  % setting pupil diameter as the pupil size measurement
Eyelink('command','binocular_enabled=YES');                                         %  binocular tracking
Eyelink('command','active_eye=BINOCULAR');

[~,fs] = Eyelink('ReadFromTracker', 'sample_rate');                                 % read sampling rate and store in property
Setup.Eyelink.fs = str2double(fs);

%% saving
% cd(targetDir)
% % EyeLinkFileName = ['e_', experimentID, phaseID];
% EyeLinkFileName = sprintf('e_%s_%s', experimentID, phaseID);
% 
% status = Eyelink('OpenFile', EyeLinkFileName);                                      % open file
% if status~=0
%     msgbox('Cannot create EDF file');                                               % if fail report back
%     Screen('CloseAll');
% end

% Eyelink('startrecording');
% WaitSecs(1);

