function eyeSave(targetDir, experimentID, phaseID)
    cd(targetDir)
    % EyeLinkFileName = ['e_', experimentID, phaseID];
    EyeLinkFileName = sprintf('e_%s_%s', experimentID, phaseID);
    
    status = Eyelink('OpenFile', EyeLinkFileName);                                       % open file
    if status~=0
        msgbox('Cannot create EDF file');                                               % if fail report back
        Screen('CloseAll');
    end
end