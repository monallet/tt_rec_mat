el = EyelinkInitDefaults(winMain);
Eyelink('command', sprintf('screen_pixel_coords = 0 0 %d %d', rectMain(3)-1, rectMain(4)-1));
Eyelink('command', 'calibration_type = HV13');
Eyelink('command', 'generate_default_targets = NO');

% Define your 13 calibration target coordinates (here’s an example layout):
scrW = rectMain(3);
scrH = rectMain(4);
calibCoords = [ round(scrW*0.5), round(scrH*0.5);  % center
                round(scrW*0.2), round(scrH*0.2);  % top-left
                round(scrW*0.5), round(scrH*0.2);  % top-center
                round(scrW*0.8), round(scrH*0.2);  % top-right
                round(scrW*0.2), round(scrH*0.8);  % bottom-left
                round(scrW*0.5), round(scrH*0.8);  % bottom-center
                round(scrW*0.8), round(scrH*0.8);  % bottom-right
                round(scrW*0.2), round(scrH*0.5);  % middle-left
                round(scrW*0.8), round(scrH*0.5);  % middle-right
                round(scrW*0.35), round(scrH*0.35);% additional point 1
                round(scrW*0.65), round(scrH*0.35);% additional point 2
                round(scrW*0.35), round(scrH*0.65);% additional point 3
                round(scrW*0.65), round(scrH*0.65)];% additional point 4
              
% Format coordinates into a vector
calibCoordsVec = calibCoords';
calibCoordsVec = calibCoordsVec(:);
Eyelink('command', sprintf('calibration_targets = %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d %d,%d', calibCoordsVec));

% Randomize the order in which the points are shown:
order = randperm(13)-1;  % random permutation of indices 0-12
orderStr = sprintf('%d,', order);
orderStr = orderStr(1:end-1);  % remove trailing comma
Eyelink('command', ['calibration_sequence = ' orderStr]);

Eyelink('command', 'calibration_samples = 14');

% Run calibration and validation:
EyelinkDoTrackerSetup(el);