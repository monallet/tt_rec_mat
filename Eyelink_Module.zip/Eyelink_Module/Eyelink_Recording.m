% Eyelink_Recording.m
% Module containing functions to control the Eyelink eye tracker.
% This code uses standard Eyelink Toolbox commands.

function EyelinkTracker = initializeEyelink()
    % Initialize the connection to the Eyelink system.
    disp('Initializing Eyelink eye tracker...');
    if ~EyelinkInit()  % Initialize Eyelink (returns 1 on success)
        error('Eyelink initialization failed.');
    end
    EyelinkTracker.status = 'initialized';
    EyelinkTracker.handle = 1;  % Typically the tracker handle is implicit
end

function calibrateEyelink(EyelinkTracker)
    % Run the Eyelink calibration procedure.
    disp('Calibrating Eyelink system...');
    EyelinkDoTrackerSetup();  % Launch the built-in calibration routine
    disp('Eyelink calibration complete.');
end

function startEyelink(EyelinkTracker)
    % Start recording eye movement data.
    disp('Starting Eyelink recording...');
    Eyelink('StartRecording');
end

function stopEyelink(EyelinkTracker)
    % Stop the eye tracking recording.
    disp('Stopping Eyelink recording...');
    Eyelink('StopRecording');
end

function shutdownEyelink(EyelinkTracker)
    % Clean up and shut down the Eyelink connection.
    disp('Shutting down Eyelink system...');
    Eyelink('Shutdown');
end