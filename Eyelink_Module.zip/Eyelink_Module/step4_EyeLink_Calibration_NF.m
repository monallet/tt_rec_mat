%% EyeLink calibration from Host-PC (fullscreen)
% 9-points calibration
%
% 2022-12-05 V1
% 
% contact:
% Felix Stockar
% felix.stockar@uzh.ch



clear all; close all; home;

% system('C:\Data\P31-Preisig\remove_icons_bar\hide_both.bat');

Screen('Preference', 'SkipSyncTests', 1);
try 
    %% OpenWindow
    rect = Screen('Rect', 0);
    windowPtr = Screen('OpenWindow', 0, [0,0,0], rect);
    el = EyelinkInitDefaults(windowPtr);
    EyelinkInit;
    Eyelink('command', 'screen_pixel_coords = %ld %ld %ld %ld', 0, 0, rect(3)-1, rect(4)-1);
    Eyelink('command', 'calibration_type = HV9');   % set calibration type (HV9 = 9 points)
    Eyelink('command', 'generate_default_targets = YES');

    center = [rect(3) / 2, rect(4) / 2];
    h_offset = center(1); 
    v_offset = center(2); %same logic applies for v_offset
    hoff = h_offset / 2;
    voff = v_offset / 2;
    coords = {
    center(1);      center(2);
    round(center(1)+hoff); center(2);
    round(center(1)-hoff); center(2);
    center(1);      round(center(2)+voff);
    center(1);      round(center(2)-voff);
    };   

    Eyelink('command',['calibration_samples = 10 ' ...
        '' ...
        'c ']);
    Eyelink('command','calibration_sequence = 0,1,2,3,4,5,6,7,8,9');
    Eyelink('command','calibration_targets = %d,%d %d,%d %d,%d %d,%d %d,%d',coords{:});
    EyelinkDoTrackerSetup(el);

catch err
    sca
    rethrow(err)
end
% system('C:\Data\P31-Preisig\remove_icons_bar\show_both.bat');

sca