%% EyeLink calibration from Host-PC (eyeCalib.m)
% 14-points calibration
%
% 2022-12-05 V1

%% OpenWindow

% addpath("C:\Data\P142-Iliopoulos\Experiment\parallelMain\Eyelink_Module") 

el = EyelinkInitDefaults(winMain);
el.backgroundColour = 255;
el.msgfontcolour = 0;
el.imgtitlecolour = 0;
el.calibrationtargetcolour = 0;
EyelinkUpdateDefaults(el);

Eyelink('command', sprintf('screen_pixel_coords = 0 0 %d %d', rectMain(3)-1, rectMain(4)-1));
Eyelink('command', 'calibration_type = HV13');
Eyelink('command', 'generate_default_targets = YES');
Eyelink('command', 'calibration_background_color = 255 255 255');
Eyelink('command', 'calibration_foreground_color = 0 0 0');

EyelinkDoTrackerSetup(el);

% calibrationStatus = waitForCalibrationAcceptance();
% 
% if strcmp(calibrationStatus, 'accepted')
%     Eyelink('startrecording');
%     eyeSave(targetDir, experimentID, phaseID);
%     WaitSecs(0.1);
% else
%     disp('Calibration failed. Please retry.');
% end

% waitForCalibrationAcceptance();
% close all; clc
% kbWaitForShift();

%% local function
% function waitForCalibrationAcceptance()
%     while true
%         if Eyelink('command', 'IsCalibrated') == 1
%             disp('Calibration accepted.');
%             break;
%         elseif Eyelink('command', 'IsCalibrated') == 0
%             disp('Calibration rejected.');
%             break;
%         end
%     end
% end