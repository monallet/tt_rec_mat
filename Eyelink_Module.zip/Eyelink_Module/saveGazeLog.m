%% [status =] Eyelink('ReceiveFile',['filename'], ['dest'], ['dest_is_path'])
status=Eyelink('ReceiveFile', EyeLinkFileName, 'C:\Data\P142-Iliopoulos\Exp_1\logfiles', 1);

if status > 0
    disp(['   *** Transfer in Datei ', EyeLinkFileName, ' erfolgreich beendet.'])
elseif status == 0
    disp('   *** Transfer abgebrochen');
else
    disp(['   *** Fehler im Transfer: Status = ', num2str(status)])
end

cd(targetDir)
save(experimentID)   % save MATLAB variables to logfile