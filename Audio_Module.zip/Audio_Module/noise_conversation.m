clear; clc; close all;

%% ========== 1. 读取对话音频，确保≥20分钟 ==========
[conversation, fs_conv] = audioread('egp555.wav');
if size(conversation,2) > 1
    % 若是多声道，转单声道
    conversation = mean(conversation,2);
end

% 我们只需要 20 分钟，用不到的可以截掉
desired_duration_sec = 20 * 60; 
total_samples_needed = desired_duration_sec * fs_conv;
if length(conversation) < total_samples_needed
    error('对话音频不足 20 分钟，请更换更长的文件或减少实验时长。');
end
conversation = conversation(1 : total_samples_needed);

%% ========== 2. 读取你的48秒噪音文件 ==========
[noise_raw, fs_noise] = audioread('pink_noise_44k1.wav');
if size(noise_raw,2) > 1
    noise_raw = mean(noise_raw,2);  % 转单声道
end

% 如果采样率不同，需要重采样
if fs_conv ~= fs_noise
    noise_raw = resample(noise_raw, fs_conv, fs_noise);
    fs_noise = fs_conv;
end

% 检查一下噪音文件最终长度
noise_length_sec = length(noise_raw) / fs_conv;
fprintf('你的噪音文件长度: %.2f 秒\n', noise_length_sec);
% 这里噪音文件只有 48s，接下来会做循环拼接。


%% ========== 3. 设置分段播放（2分钟一段） & 随机噪声类型 ==========
chunk_duration_sec = 2 * 60;      % 每段2分钟 => 120秒
chunk_size = chunk_duration_sec * fs_conv;
num_chunks = floor(length(conversation)/chunk_size);  % 20分钟 / 2分钟 => 10段

% 定义三种噪音类型: NN(无噪音)、70dB、75dB
% 用 NaN 表示无噪声，这样逻辑上易区分
noise_options = [NaN, 70, 75];

% 随机序列（长度=num_chunks），每个元素 ∈ {1, 2, 3}
random_seq = randi([1,3], [num_chunks,1]);

% 参考声压
p0 = 20e-6;

%% ========== 4. 循环生成并叠加到对话里 ==========
final_output = zeros(size(conversation)); 
current_index = 1;

for i = 1 : num_chunks
    start_i = current_index;
    end_i   = current_index + chunk_size - 1;

    % ---- 4.1) 对话片段 (2分钟) ----
    conv_chunk = conversation(start_i : end_i);

    % ---- 4.2) 取出 2分钟 对应的噪音 ----
    %      思路: 噪音文件只有48s, 我们要先循环它到≥120s, 再截取120s
    chosen_noise = noise_options(random_seq(i));

    if isnan(chosen_noise)
        % ====== 4.2.a) 无噪音(NN) ======
        noise_chunk = zeros(chunk_size, 1);
        fprintf('第 %d 段: No Noise\n', i);

    else
        % ====== 4.2.b) 有噪音(70 或 75 dB) ======
        noise_dB = chosen_noise;
        fprintf('第 %d 段: %g dB 噪音\n', i, noise_dB);

        % 先决定要拼接几次, 使其长度 ≥ 120s
        times_needed = ceil(chunk_size / length(noise_raw)); 
        % 若 chunk_size=120s*fs, 而 noise_raw=48s*fs,
        % times_needed = ceil(120/48)=3

        % 拼接
        noise_tiled = repmat(noise_raw, times_needed, 1);
        % 现在 noise_tiled 长度 >= chunk_size

        % 截取前 chunk_size 样点 => 精确 2分钟
        noise_chunk = noise_tiled(1 : chunk_size);

        % 现在再做**声压级**缩放 => 70 或 75 dB SPL
        desired_rms = p0 * 10^(noise_dB/20);
        current_rms = rms(noise_chunk);

        if current_rms < 1e-12
            % 如果噪音里全是0(极少见)，防止除0
            noise_chunk = desired_rms * randn(size(noise_chunk));
        else
            scale_factor = desired_rms / current_rms;
            noise_chunk  = noise_chunk * scale_factor;
        end
    end

    % ---- 4.3) 混合(对话 + 噪音) ----
    mixed_chunk = conv_chunk + noise_chunk;

    % ---- 4.4) 简单防溢出归一化 ----
    peak_val = max(abs(mixed_chunk));
    if peak_val > 0
        mixed_chunk = mixed_chunk / peak_val * 0.99;
    end

    % ---- 4.5) 存入 final_output ----
    final_output(start_i : end_i) = mixed_chunk;

    current_index = end_i + 1;  % 移动索引
end

fprintf('总共 %d 段处理完毕, 最终音频时长 = %.2f 分钟.\n', ...
    num_chunks, length(final_output)/fs_conv/60);

%% ========== 5. 播放或写文件 ==========
playDevice = 19;
pPlay1 = PsychPortAudio('Open', playDevice, 1, 1, fs_conv);
PsychPortAudio('FillBuffer', pPlay1, final_output);
PsychPortAudio('Start', pPlay1, 1, 0, 1);
% player = audioplayer(final_output, fs_conv);
% fprintf('开始播放 20 分钟混合音频...\n');
% playblocking(player);

audiowrite('Conversation_20min_withLoopedNoise.wav', final_output, fs_conv);
fprintf('已保存为 "Conversation_20min_withLoopedNoise.wav".\n');

PsychPortAudio('Stop', pPlay1, 1, 0, 1);
PsychPortAudio('Close', pPlay1, 1, 0, 1);