function resting_state_high_noise(noiseDB, duration)
% Resting State 3 with High-Level Noise (Two Independent Booths)
% Author: [Shan Gao, Moana Chen]
% Date: [27.03.2025]
    
    initialiseSoundDevices;
    fs = 48000;           %
    p0 = 20e-6;           % 参考声压
    
    noiseFile = 'pink_noise_44k1.wav';
    [noiseRaw, fsNoise] = audioread(noiseFile);
    if size(noiseRaw, 2) > 1
        noiseRaw = mean(noiseRaw, 2);
    end
    if fsNoise ~= fs
        noiseRaw = resample(noiseRaw, fs, fsNoise);
    end
    
    playHandle1 = PsychPortAudio('Open', playDeviceID1, 1, 1, fs, 1); 
    playHandle2 = PsychPortAudio('Open', playDeviceID2, 1, 1, fs, 1);
    
    totalSamples = duration * fs;
    noiseData = repmat(noiseRaw, ceil(totalSamples / length(noiseRaw)), 1);
    noiseData = noiseData(1:totalSamples);
    desired_rms = p0 * 10^(noiseDB / 20);
    scaleFactor = desired_rms / rms(noiseData);
    noiseData = noiseData * scaleFactor;
    
    PsychPortAudio('FillBuffer', playHandle1, noiseData');
    PsychPortAudio('FillBuffer', playHandle2, noiseData');
    
    PsychPortAudio('Start', playHandle1, 1, 0, 1);
    PsychPortAudio('Start', playHandle2, 1, 0, 1);
    % WaitSecs(duration);

    % PsychPortAudio('Stop', playHandle1);
    % PsychPortAudio('Stop', playHandle2);
    % PsychPortAudio('Close', playHandle1);
    % PsychPortAudio('Close', playHandle2);

end