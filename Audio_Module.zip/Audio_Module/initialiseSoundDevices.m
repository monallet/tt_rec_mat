%% initialise sound devices 
devices = PsychPortAudio('GetDevices');

% % For test A,
% recordDeviceName_A = 'MacBook Pro Microphone';
% playDeviceName_A   = 'MacBook Pro Speakers';
% 
% % For test B,
% recordDeviceName_B = 'MacBook Pro Microphone';
% playDeviceName_B   = 'MacBook Pro Speakers';

% For booth A,
recordDeviceName_A = 'Analog (9+10) (RME UFX II)';
playDeviceName_A   = 'Analog (9+10) (RME UFX II)';

% For booth B,
recordDeviceName_B = 'Analog (11+12) (RME UFX II)';
playDeviceName_B   = 'Analog (11+12) (RME UFX II)';

% Find device indices using our helper function:
recordDeviceID1 = findDeviceByName(recordDeviceName_A, devices, 'input');
playDeviceID1 = findDeviceByName(playDeviceName_A, devices, 'output');

% recordDeviceID2 = findDeviceByName(recordDeviceName_B, devices, 'input');
recordDeviceID2 = findDeviceByName(recordDeviceName_B, devices, 'input');
playDeviceID2 = findDeviceByName(playDeviceName_B, devices, 'output');

fprintf('Booth A: Using input device "%s" (index %d) and output device "%s" (index %d)\n', ...
    recordDeviceName_A, recordDeviceID1, playDeviceName_A, playDeviceID1);
fprintf('Booth B: Using input device "%s" (index %d) and output device "%s" (index %d)\n', ...
    recordDeviceName_B, recordDeviceID2, playDeviceName_B, playDeviceID2);