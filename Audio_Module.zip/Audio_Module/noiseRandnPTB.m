function noiseRandnPTB(totalDuration, numCycleEvents, experimentID, playDeviceID1, playDeviceID2, noiseLogDir, noiseFile, noisePhase)
    % this function randomise the noise levels, sending the triggers, and
    % save the log as a text file.
    % Author: [Moana Chen]
    % Date: [27.03.2025]

    % %% 0. set System Volume (for win)
    % try
    %     system('nircmd.exe setsysvolume 32768');
    %     fprintf('System volume set to 50%% using nircmd.\n');
    % catch
    %     warning('Unable to set system volume. Please adjust manually if needed.');
    % end
    
    %% 1. audio settings
    fs = 44100; 
    eventDuration = totalDuration / numCycleEvents; 
    % InitializePsychSound(); % only for testing
    % initialiseSoundDevices;
    playHandle1 = PsychPortAudio('Open', playDeviceID1, 1, 1, fs, 1);
    playHandle2 = PsychPortAudio('Open', playDeviceID2, 1, 1, fs, 1);

    % noiseFile = 'pink_noise_44k1.wav';
    [noiseRaw, fsNoise] = audioread(noiseFile);
    if size(noiseRaw,2) > 1
        noiseRaw = mean(noiseRaw, 2); 
    end
    if fsNoise ~= fs
        noiseRaw = resample(noiseRaw, fs, fsNoise);
    end

    %% 2. Randomised event
    levelsArray = repmat([72, 78, NaN], 1, ceil(numCycleEvents/3));
    levelsArray = levelsArray(1:numCycleEvents); % stop with 6 events
    % randomise the order for one cycle
    cycleLevels = levelsArray(randperm(numCycleEvents));
    cycleEvents = struct('start', [], 'end', [], 'level', []);
    for i = 1:numCycleEvents
        cycleEvents(i).start = (i-1)*eventDuration;
        cycleEvents(i).end = i*eventDuration;
        cycleEvents(i).level = cycleLevels(i);
    end
    
    %% 3. Loop
    noisePointer = 1;
    refPressure = 20e-6; 
    trigger_port = config_io();

    for evt = 1:numCycleEvents
        currentTime = (evt-1) * eventDuration;
        cycleIdx = mod(evt-1, numCycleEvents) + 1;
        currentLevel = cycleEvents(cycleIdx).level;
        
        fprintf('Event %d (Time: %.2f - %.2f s): Playing %g dB noise.\n', ...
            evt, currentTime, currentTime+eventDuration, currentLevel);
        drawnow;
        SendTrig(trigger_port, 101); % send trigger at the beginning of each event
        Eyelink('Message', ('REC255'));  % new message-strings according to Natalyias instructions
        % disp('s')
        segmentLength = eventDuration * fs;
        [noiseSegment, noisePointer] = getNoiseSegment(noiseRaw, noisePointer, segmentLength);
        
        desiredRMS = refPressure * 10^(currentLevel/20);
        currentRMS = rms(noiseSegment);
        if currentRMS < 1e-12
            noiseSegment = desiredRMS * randn(segmentLength, 1);
        else
            noiseSegment = noiseSegment * (desiredRMS / currentRMS);
        end
        
        PsychPortAudio('FillBuffer', playHandle1, noiseSegment');
        PsychPortAudio('FillBuffer', playHandle2, noiseSegment');
        PsychPortAudio('Start', playHandle1, 1, 0, 1);  
        PsychPortAudio('Start', playHandle2, 1, 0, 1);

        SendTrig(trigger_port, 102); % send another at the end of each
        Eyelink('Message', ('END255'));  % new message-strings according to Natalyias instructions
        % disp('e')
        PsychPortAudio('Stop', playHandle1, 1); 
        PsychPortAudio('Stop', playHandle2, 1); 
    end

    PsychPortAudio('Close', playHandle1);
    PsychPortAudio('Close', playHandle2);

    %% 4. save log
    NoiseLog = fullfile(noiseLogDir, sprintf('p142_%s_3AB_%s_noise_event.txt', experimentID, noisePhase));
    fid = fopen(NoiseLog, 'w');
    if fid == -1
        warning('Unable to open %s for writing.', NoiseLog);
    else
        fprintf(fid, 'Event Order:\n');
        fprintf(fid, 'Event\tStart_Time(s)\tEnd_Time(s)\tdB_Level\n');
        for evt = 1:numCycleEvents
            startTime = (evt-1) * eventDuration;
            endTime = evt * eventDuration;
            cycleIdx = mod(evt-1, numCycleEvents) + 1;
            currentLevel = cycleEvents(cycleIdx).level;
            fprintf(fid, '%d\t%.2f\t%.2f\t%g\n', evt, startTime, endTime, currentLevel);
        end
        fclose(fid);
    end
    
end




