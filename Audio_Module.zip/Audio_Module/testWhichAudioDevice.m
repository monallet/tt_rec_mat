function testWhichAudioDevice(deviceID)
    % testSpecificAudioDevice(deviceID)
    %
    % 1. Initialises PsychSound
    % 2. Lists available audio devices
    % 3. Opens the specified deviceID for playback
    % 4. Plays a short beep through that device

    % 0) Make sure you have the latest Psychtoolbox and that any required 
    %    drivers or libraries are installed (e.g., MSVC Redistributable on Windows).

    % 1) Initialize PsychSound
    InitializePsychSound();

    % 2) List available devices
    devices = PsychPortAudio('GetDevices');
    disp('--- Available Audio Devices ---');
    for i = 1:length(devices)
        fprintf('Device %d: %s (Input Ch: %d, Output Ch: %d)\n', ...
            devices(i).DeviceIndex, ...
            devices(i).DeviceName, ...
            devices(i).NrInputChannels, ...
            devices(i).NrOutputChannels);
    end
    disp('--------------------------------');

    % 3) Open the specified deviceID for playback
    %    mode = 1 means we open it for playback only.
    %    reqlatencyclass = 1 tries for low latency.
    %    freq = 44100 is our sampling rate.
    %    chans = 2 for stereo beep (if your device has at least 2 output channels).
    mode = 1;            % playback
    reqlatencyclass = 1; % low latency
    freq = 44100;        % sampling rate
    chans = 2;           % stereo
    pahandle = PsychPortAudio('Open', deviceID, mode, reqlatencyclass, freq, chans);

    % 4) Generate a short test tone (2-second beep at 440 Hz)
    beepFreq = 440;         % A4 note
    beepDuration = 2;       % seconds
    timevec = 0 : 1/freq : beepDuration;
    beep = 0.1 * sin(2*pi*beepFreq*timevec);  % amplitude scaled down to 0.1

    % If chans = 2, create a stereo buffer by duplicating the beep in both rows
    stereoBeep = [beep; beep];

    % Fill the buffer with our test beep
    PsychPortAudio('FillBuffer', pahandle, stereoBeep);

    % Start playback; 1 repetition, start now (0), don’t wait for start (1 means "return once playback starts").
    PsychPortAudio('Start', pahandle, 1, 0, 1);

    % Wait for the beep to finish
    WaitSecs(beepDuration);

    % Stop and close the device
    PsychPortAudio('Stop', pahandle);
    PsychPortAudio('Close', pahandle);

    disp('Test tone playback finished.');
end



% Device 0: Microsoft Sound Mapper - Input (Input Ch: 2, Output Ch: 0)
% Device 1: Analog (9+10) (RME UFX II) (Input Ch: 2, Output Ch: 0)
% Device 2: Analog (1+2) (RME UFX II) (Input Ch: 2, Output Ch: 0)
% Device 3: Microsoft Sound Mapper - Output (Input Ch: 0, Output Ch: 2)
% ..inbooth speaker
% Device 4: Speakers (RME UFX II) (Input Ch: 0, Output Ch: 2) ..inbooth speaker
% Device 5: Analog (9+10) (RME UFX II) (Input Ch: 0, Output Ch: 2) ..inbooth speaker
% Device 6: Analog (9+10) (RME UFX II) (Input Ch: 0, Output Ch: 2) ..inbooth speaker
% Device 7: Speakers (RME UFX II) (Input Ch: 0, Output Ch: 2) ..inbooth speaker
% Device 8: Analog (9+10) (RME UFX II) (Input Ch: 2, Output Ch: 0)
% Device 9: Analog (1+2) (RME UFX II) (Input Ch: 2, Output Ch: 0)
% Device 10: Analog (9+10) (RME UFX II) [Loopback] (Input Ch: 2, Output Ch: 0)
% Device 11: Speakers (RME UFX II) [Loopback] (Input Ch: 2, Output Ch: 0)
% Device 12: FrontMic (Realtek HD Audio Front Mic input) (Input Ch: 2, Output Ch: 0)
% Device 13: Headphones (Realtek HD Audio 2nd output) (Input Ch: 0, Output Ch: 2) ..inbooth speaker
% Device 14: Speakers (Realtek HD Audio output) (Input Ch: 0, Output Ch: 2)
% ..outbooth sound (notusable)
% Device 15: Stereo Mix (Realtek HD Audio Stereo input) (Input Ch: 2, Output Ch: 0)
% Device 16: Output (AMD HD Audio HDMI out #0) (Input Ch: 0, Output Ch: 2) ..outbooth speaker
% Device 17: Output (AMD HD Audio HDMI out #3) (Input Ch: 0, Output Ch: 2)
% ..inbooth speaker low volumn
% Device 18: Analog (9+10) (MADIface Analog (9+10)) (Input Ch: 0, Output Ch: 2)
% Device 19: Analog (9+10) (MADIface Analog (9+10)) (Input Ch: 2, Output Ch: 0)
% Device 20: Analog (1+2) (MADIface Analog (1+2)) (Input Ch: 0, Output Ch: 2)
% Device 21: Analog (1+2) (MADIface Analog (1+2)) (Input Ch: 2, Output Ch: 0)