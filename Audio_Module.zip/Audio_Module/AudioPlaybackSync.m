function recordAndPlaybackAudio(audioData, fs, csvFilename)
% recordAndPlaybackAudio plays back the provided audio and records the external
% button press intervals (self-evaluation responses) during playback.
%
% The experimenter first confirms the start via the external button. When the
% audio starts, the system records button-press intervals until the audio ends.
% The responses are then saved in a CSV file with timecodes in the format:
%   HH:MM:SS:FF-HH:MM:SS:FF, state
%
% Inputs:
%   audioData   - Audio data vector.
%   fs          - Sampling frequency.
%   csvFilename - Output CSV filename (including .csv).

    disp('=== Audio Playback & Self-Evaluation Module ===');
    disp('Experimenter: Press either Shift key to start audio playback.');
    KbWaitForShift();  % Wait for experimenter confirmation

    % Start audio playback and record the precise start time.
    disp('Playing back audio...');
    playbackStartTime = GetSecs;
    sound(audioData, fs);
    
    % Determine the total playback duration.
    audioDuration = length(audioData) / fs;
    
    % Display self-evaluation instructions.
    disp('Self-Evaluation:');
    disp('If you feel connected, press and hold the Shift key until you feel no more,');
    disp('and press and hold again if you feel connected later.');
    
    % Record the button press intervals during audio playback.
    syncResponses = recordSyncResponses(playbackStartTime, audioDuration);
    
    % Write the recorded intervals to a CSV file.
    writeSyncResponsesToCSV(syncResponses, csvFilename);
end

%% ------------------------------------------------------------------------
function KbWaitForShift()
% KbWaitForShift waits until the user presses either left or right Shift key.
    KbName('UnifyKeyNames');
    shiftKeys = [KbName('LeftShift'), KbName('RightShift')];
    while true
        [keyIsDown, ~, keyCode] = KbCheck;
        if keyIsDown && any(keyCode(shiftKeys))
            break;
        end
    end
    % Small debounce pause
    WaitSecs(0.2);
end

%% ------------------------------------------------------------------------
function syncResponses = recordSyncResponses(playbackStartTime, audioDuration)
% recordSyncResponses polls for Shift-key presses during audio playback and
% records the intervals when the button is held. Timestamps are relative to
% playbackStartTime.

    % Polling interval (in seconds)
    pollInterval = 0.01;
    
    % Detect either Shift key
    KbName('UnifyKeyNames');
    shiftKeys = [KbName('LeftShift'), KbName('RightShift')];

    syncIntervals = [];   
    responseIdx = 1;
    wasPressed = false;
    currentIntervalStart = [];
    
    t0 = playbackStartTime;
    currentTime = GetSecs;
    
    while (currentTime - t0) < audioDuration
        [keyIsDown, keyTime, keyCode] = KbCheck;
        if keyIsDown && any(keyCode(shiftKeys))
            if ~wasPressed
                wasPressed = true;
                currentIntervalStart = keyTime;
            end
        else
            if wasPressed
                wasPressed = false;
                intervalStart = currentIntervalStart;
                intervalEnd = GetSecs;
                syncIntervals(responseIdx, :) = [intervalStart, intervalEnd];
                responseIdx = responseIdx + 1;
            end
        end
        pause(pollInterval);
        currentTime = GetSecs;
    end
    
    % If the button is still pressed at the end, close the final interval.
    if wasPressed
        intervalStart = currentIntervalStart;
        intervalEnd = playbackStartTime + audioDuration;
        syncIntervals(responseIdx, :) = [intervalStart, intervalEnd];
    end
    
    % Convert absolute timestamps to times relative to playbackStartTime.
    if ~isempty(syncIntervals)
        syncIntervals = syncIntervals - playbackStartTime;
    end
    
    % Build a full timeline with both sync and out intervals.
    fullResponses = {};
    fullIdx = 1;
    lastTime = 0;
    for i = 1:size(syncIntervals,1)
        startSync = syncIntervals(i,1);
        endSync   = syncIntervals(i,2);
        if startSync > lastTime
            % Interval when button was not pressed
            fullResponses{fullIdx,1} = lastTime;
            fullResponses{fullIdx,2} = startSync;
            fullResponses{fullIdx,3} = 'out';
            fullIdx = fullIdx + 1;
        end
        % Interval when button is pressed
        fullResponses{fullIdx,1} = startSync;
        fullResponses{fullIdx,2} = endSync;
        fullResponses{fullIdx,3} = 'sync';
        fullIdx = fullIdx + 1;
        lastTime = endSync;
    end
    if lastTime < audioDuration
        fullResponses{fullIdx,1} = lastTime;
        fullResponses{fullIdx,2} = audioDuration;
        fullResponses{fullIdx,3} = 'out';
    end
    
    syncResponses = fullResponses;
    disp('Self-evaluation response recording complete.');
end

%% ------------------------------------------------------------------------
function writeSyncResponsesToCSV(syncResponses, csvFilename)
% writeSyncResponsesToCSV writes the sync responses to a CSV file.
% Each line follows the format:
%   HH:MM:SS:FF-HH:MM:SS:FF, state
% where FF represents frames (24 fps).

    frameRate = 24;  
    fid = fopen(csvFilename, 'w');
    if fid == -1
        error('Cannot open file: %s', csvFilename);
    end
    
    for i = 1:size(syncResponses,1)
        startSec = syncResponses{i,1};
        endSec   = syncResponses{i,2};
        state    = syncResponses{i,3};
        startCode = secondsToTimecode(startSec, frameRate);
        endCode   = secondsToTimecode(endSec, frameRate);
        fprintf(fid, '%s-%s, %s\n', startCode, endCode, state);
    end
    fclose(fid);
    disp(['Self-evaluation responses saved to ', csvFilename]);
end

%% ------------------------------------------------------------------------
function timecode = secondsToTimecode(secondsVal, frameRate)
% secondsToTimecode converts a seconds value into a timecode string (HH:MM:SS:FF).

    hours = floor(secondsVal / 3600);
    minutes = floor(mod(secondsVal, 3600) / 60);
    secs = floor(mod(secondsVal, 60));
    frames = floor((secondsVal - floor(secondsVal)) * frameRate);
    timecode = sprintf('%02d:%02d:%02d:%02d', hours, minutes, secs, frames);
end


% Backup trial 1
% function recordAndPlaybackAudio(audioData, fs, csvFilename)
% % recordAndPlaybackAudio plays back the recorded audio and records external
% % button press events (self-evaluation) for synchronization.
% %
% % The experimenter first confirms the start of playback via an external button.
% % When audio starts, the function continuously polls the external button 
% % (assumed here to be the 'space' key) and records the intervals (with timestamps)
% % during which the participant holds the button. After playback, the intervals 
% % are saved in a CSV file in the format: 
% %   HH:MM:SS:FF-HH:MM:SS:FF, state
% %
% % Inputs:
% %   audioData   - Recorded audio data (column vector).
% %   fs          - Sampling frequency.
% %   csvFilename - Filename (including .csv) for saving sync responses.
% %
% % Example:
% %   recordAndPlaybackAudio(audioData, fs, 'SyncResponses.csv');
% 
%     disp('=== Audio Playback & Self-Evaluation Module ===');
%     disp('Experimenter: Press the external button to start audio playback.');
%     KbWait([], 2);  % Wait for experimenter confirmation
% 
%     % Start audio playback and note the playback start time.
%     disp('Playing back audio...');
%     playbackStartTime = GetSecs;
%     sound(audioData, fs);
% 
%     % Calculate the total playback duration.
%     audioDuration = length(audioData) / fs;
% 
%     % Display self-evaluation instructions during playback.
%     disp('Self-Evaluation:');
%     disp('At this moment, how do you feel connected to the other speaker?');
%     disp('If you feel connected, press and hold the button until you feel no more,');
%     disp('and press and hold again if you feel connected later.');
% 
%     % Record the sync responses (button press intervals) during audio playback.
%     syncResponses = recordSyncResponses(playbackStartTime, audioDuration);
% 
%     % Write the collected responses to a CSV file.
%     writeSyncResponsesToCSV(syncResponses, csvFilename);
% end
% 
% %% ------------------------------------------------------------------------
% function syncResponses = recordSyncResponses(playbackStartTime, audioDuration)
% % recordSyncResponses polls the external button (here assumed to be 'space')
% % throughout the audio playback. It records intervals (start and end times)
% % when the button is held, then returns a cell array with each interval and its state.
% %
% % The timestamps are relative to the playback start time.
% %
% % Output:
% %   syncResponses - Cell array with rows: {start_time, end_time, state}
% %                   where state is either 'sync' (button held) or 'out' (button not held).
% 
%     pollInterval = 0.01;         % Seconds between each poll
%     keyOfInterest = KbName('space');  % Key to check (customize if needed)
% 
%     syncIntervals = [];   % Will hold rows [start, end] for sync intervals
%     responseIdx = 1;
%     wasPressed = false;
%     currentIntervalStart = [];
% 
%     t0 = playbackStartTime;
%     currentTime = GetSecs;
% 
%     while (currentTime - t0) < audioDuration
%         [keyIsDown, keyTime, keyCode] = KbCheck;
%         if keyIsDown && keyCode(keyOfInterest)
%             if ~wasPressed
%                 wasPressed = true;
%                 currentIntervalStart = keyTime;
%             end
%         else
%             if wasPressed
%                 wasPressed = false;
%                 intervalStart = currentIntervalStart;
%                 intervalEnd = GetSecs;
%                 syncIntervals(responseIdx, :) = [intervalStart, intervalEnd];
%                 responseIdx = responseIdx + 1;
%             end
%         end
%         pause(pollInterval);
%         currentTime = GetSecs;
%     end
% 
%     % If the button is still pressed at the end, close the final interval.
%     if wasPressed
%         intervalStart = currentIntervalStart;
%         intervalEnd = playbackStartTime + audioDuration;
%         syncIntervals(responseIdx, :) = [intervalStart, intervalEnd];
%     end
% 
%     % Convert the absolute timestamps to times relative to playbackStartTime.
%     if ~isempty(syncIntervals)
%         syncIntervals = syncIntervals - playbackStartTime;
%     end
% 
%     % Build a complete timeline that includes both sync and out intervals.
%     fullResponses = {};
%     fullIdx = 1;
%     lastTime = 0;
% 
%     for i = 1:size(syncIntervals,1)
%         startSync = syncIntervals(i,1);
%         endSync   = syncIntervals(i,2);
%         if startSync > lastTime
%             % 'out' interval (button not pressed)
%             fullResponses{fullIdx,1} = lastTime;
%             fullResponses{fullIdx,2} = startSync;
%             fullResponses{fullIdx,3} = 'out';
%             fullIdx = fullIdx + 1;
%         end
%         % 'sync' interval (button held)
%         fullResponses{fullIdx,1} = startSync;
%         fullResponses{fullIdx,2} = endSync;
%         fullResponses{fullIdx,3} = 'sync';
%         fullIdx = fullIdx + 1;
%         lastTime = endSync;
%     end
%     if lastTime < audioDuration
%         fullResponses{fullIdx,1} = lastTime;
%         fullResponses{fullIdx,2} = audioDuration;
%         fullResponses{fullIdx,3} = 'out';
%     end
% 
%     syncResponses = fullResponses;
%     disp('Self-evaluation response recording complete.');
% end
% 
% %% ------------------------------------------------------------------------
% function writeSyncResponsesToCSV(syncResponses, csvFilename)
% % writeSyncResponsesToCSV writes the sync responses into a CSV file.
% % Each line in the file follows the format:
% %   HH:MM:SS:FF-HH:MM:SS:FF, state
% % (FF represents frames, assuming 24 frames per second.)
% 
%     frameRate = 24;  % Frames per second for timecode conversion.
%     fid = fopen(csvFilename, 'w');
%     if fid == -1
%         error('Cannot open file: %s', csvFilename);
%     end
% 
%     for i = 1:size(syncResponses,1)
%         startSec = syncResponses{i,1};
%         endSec   = syncResponses{i,2};
%         state    = syncResponses{i,3};
%         startCode = secondsToTimecode(startSec, frameRate);
%         endCode   = secondsToTimecode(endSec, frameRate);
%         fprintf(fid, '%s-%s, %s\n', startCode, endCode, state);
%     end
%     fclose(fid);
%     disp(['Self-evaluation responses saved to ', csvFilename]);
% end
% 
% %% ------------------------------------------------------------------------
% function timecode = secondsToTimecode(secondsVal, frameRate)
% % secondsToTimecode converts seconds to a timecode string (HH:MM:SS:FF).
% 
%     hours = floor(secondsVal / 3600);
%     minutes = floor(mod(secondsVal, 3600) / 60);
%     secs = floor(mod(secondsVal, 60));
%     frames = floor((secondsVal - floor(secondsVal)) * frameRate);
%     timecode = sprintf('%02d:%02d:%02d:%02d', hours, minutes, secs, frames);
% end
% 
% 
