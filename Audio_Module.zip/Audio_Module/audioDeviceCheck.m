InitializePsychSound();
% retrieve the list of available audio devices
devices = PsychPortAudio('GetDevices');

% loop through each device and display its index and name
for i = 1:length(devices)
    % Depending on the version of Psychtoolbox, the device index may be stored as 'deviceid' or 'DeviceIndex'
    if isfield(devices(i), 'deviceid')
        deviceIndex = devices(i).deviceid;
    else
        deviceIndex = devices(i).DeviceIndex;
    end
    
    % Similarly, the device name might be under 'deviceName' or 'DeviceName'
    if isfield(devices(i), 'deviceName')
        deviceName = devices(i).deviceName;
    else
        deviceName = devices(i).DeviceName;
    end
    
    fprintf('Device %d: %s\n', deviceIndex, deviceName);
    fprintf('  NrInputChannels:  %d\n', devices(i).NrInputChannels);
    fprintf('  NrOutputChannels: %d\n', devices(i).NrOutputChannels);
    fprintf('  LowInputLatency:  %f\n', devices(i).LowInputLatency);
    fprintf('  HighInputLatency: %f\n', devices(i).HighInputLatency);
    fprintf('  LowOutputLatency: %f\n', devices(i).LowOutputLatency);
    fprintf('  HighOutputLatency: %f\n\n', devices(i).HighOutputLatency);
end
