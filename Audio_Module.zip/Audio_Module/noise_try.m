function noise_try()
    % ========== 0. (可选) 用nircmd设置系统音量 (Windows) ==========
    % 如果不需要可注释或删除此段
    try
        system('nircmd.exe setsysvolume 32768'); % 约50%音量(65535=最大)
        disp('已调用nircmd.exe将系统音量调至50%.');
    catch
        warning('无法调用nircmd.exe，可能非Windows或未安装此工具，请手动设置或忽略。');
    end

    % ========== 1. 音频全局设置 ==========
    fs = 48000;             % 采样率，可根据设备实际情况改
    frameSize = 1024;       % 每帧大小(影响延迟)
    totalChunks = 6;        % 共6段 => (NN,70,75) x 2
    chunkDurationSec = 120; % 每段2分钟 => 120秒 => 总12分钟

    % ========== 2. 指定音频设备(输入与输出) ==========
    % 可在命令行中:
    %   devW = audioDeviceWriter;
    %   getAudioDevices(devW)
    % 查看可用输出设备列表，然后将 myOutputDevice 改为你想用的输出设备名。
    myOutputDevice = "audioplayer";  % <--- 修改为实际输出设备
    % 同理，对输入设备:
    myInputDevice  = "Focusrite USB ASIO";  % <--- 修改为实际输入(支持双通道)

    % 创建双通道输入 (2路麦克风 => Person1 / Person2)
    deviceReader = audioDeviceReader( ...
        'SampleRate', fs, ...
        'SamplesPerFrame', frameSize, ...
        'Device', myInputDevice, ...
        'NumChannels', 2 ...
    );

    % 创建双通道输出 (2路耳机 => Person1Ear / Person2Ear)
    deviceWriter = audioDeviceWriter( ...
        'SampleRate', fs, ...
        'Device', myOutputDevice, ...
        'SupportVariableSizeInput', true, ...
        'NumChannels', 2 ...
    );

    % ========== 3. 读取噪声文件 ==========
    noiseFile = '/MATLAB Drive/Noise/pink noise/pink_noise_44k1.wav'; 
   %noiseFile = '/Users/gaoshan/Desktop/MA Thesis/Noise/white noise/Multi_4F,4M_talker_babble_CH_GE.wav';
   %noiseFile = '/Users/gaoshan/Desktop/MA Thesis/Noise/white noise/SpchNz24k.wav'; 
   %noiseFile = '/Users/gaoshan/Desktop/MA Thesis/Noise/white noise/SpchNz44.wav';
   %noiseFile = '/Users/gaoshan/Desktop/MA Thesis/Noise/white noise/white_noise_44k1.wav';


    [noiseRaw, fsNoise] = audioread(noiseFile);
    if size(noiseRaw, 2) > 1
        noiseRaw = mean(noiseRaw,2);  % 转单声道
    end
    if fsNoise ~= fs
        noiseRaw = resample(noiseRaw, fs, fsNoise);
    end

    % ========== 4. 噪声模式: NN / 70 dB / 75 dB, 每种重复2次, 随机顺序 ==========
    % 用 NaN 表示无噪声, 70表示70 dB, 75表示75 dB
    baseLevels = [NaN, 70, 75];
    repeatedLevels = repmat(baseLevels, 1, 2);  % => [NaN 70 75 NaN 70 75]
    randomOrder = randperm(length(repeatedLevels));
    noiseSequence = repeatedLevels(randomOrder); % 打乱顺序 => 6段

    % ========== 5. 开始实验循环 ==========
    disp('=== 开始实验: 12分钟, 每2分钟切换一次噪声, 共6段 ===');

    startTime = tic;           % 全局计时
    currentChunkIndex = 1;     % 第1段
    chunkStartTime = 0;        % 第1段起始时刻
    mixedBuffer = [];          % 用于保存混合后音频(可选)

    % 初始化本段噪声模式
    currentNoiseDB = noiseSequence(currentChunkIndex);
    fprintf('>>> 第1段, 噪声: %s\n', noiseModeText(currentNoiseDB));

    % 指针, 用于在 noiseRaw 中循环取帧
    noisePointer = 1;
    p0 = 20e-6;  % 参考声压(若做绝对dB SPL)

    while true
        % ---- 5.1) 从麦克风读取一帧(双通道: [frameSize,2]) ----
        micFrame = deviceReader();     % 读到 [frameSize,2]
        % 分离两个麦克风通道 => Person1 / Person2
        person1Mic = micFrame(:,1);
        person2Mic = micFrame(:,2);

        % ---- 5.2) 生成与帧等长的噪声(单声道noiseMono), 缩放到指定 dB(若不是NN) ----
        if isnan(currentNoiseDB)
            % 无噪声
            noiseMono = zeros(frameSize,1);
        else
            % 70 or 75 dB => 计算目标RMS并缩放
            noiseMono = getNoiseFrame(noiseRaw, noisePointer, frameSize);
            noisePointer = noisePointer + frameSize;

            desired_rms = p0 * 10^(currentNoiseDB / 20); % 根据dB计算目标RMS
            current_rms = rms(noiseMono);
            if current_rms < 1e-12
                % 避免除0
                noiseMono = desired_rms * randn(size(noiseMono));
            else
                scaleFactor = desired_rms / current_rms;
                noiseMono = noiseMono * scaleFactor;
            end
        end

        % ---- 5.3) 按需求合成每个人耳机听到的信号 ----

        % 方案A: 每个人只听“对方的麦克风 + 噪声”
        person1Out = person2Mic + noiseMono;
        person2Out = person1Mic + noiseMono;

        % 如果想两人都听“自己 + 对方 + 噪声”，可以改为:
        % person1Out = person1Mic + person2Mic + noiseMono;
        % person2Out = person1Mic + person2Mic + noiseMono;

        % 组装成双通道 [frameSize,2]
        mixedFrame = [person1Out, person2Out];

        % (可选)防止削波
        peakVal = max(abs(mixedFrame), [], 'all');
        if peakVal>0.99
            mixedFrame = mixedFrame / peakVal * 0.99;
        end

        % ---- 5.4) 播放到耳机/扬声器 ----
        deviceWriter(mixedFrame);

        % ---- 5.5) 录制到内存(可选, 若文件过大会占内存) ----
        mixedBuffer = [mixedBuffer; mixedFrame]; %#ok<AGROW>

        % ---- 5.6) 检查是否到达 2 分钟 ----
        elapsedSec = toc(startTime);
        currentChunkElapsed = elapsedSec - chunkStartTime;
        if currentChunkElapsed >= chunkDurationSec
            % 切换到下一段
            currentChunkIndex = currentChunkIndex + 1;
            if currentChunkIndex > totalChunks
                disp('=== 已完成全部6段(12分钟) ===');
                break;
            end
            currentNoiseDB = noiseSequence(currentChunkIndex);
            noisePointer = 1; % 让下一段噪声从头开始(如需连续则可不重置)
            chunkStartTime = elapsedSec;
            fprintf('>>> 第%d段, 噪声: %s\n', currentChunkIndex, noiseModeText(currentNoiseDB));
        end

        % (可选) 若想确保12分钟后强制结束
        if elapsedSec >= totalChunks * chunkDurationSec
            disp('=== 达到12分钟总时长, 强制结束 ===');
            break;
        end
    end

    % ========== 6. 释放设备 & 保存音频(可选) ==========
    release(deviceReader);
    release(deviceWriter);

    disp('已结束实验并释放音频设备.');

    % 保存到WAV(双通道), 若不需可注释
    outFile = 'realtimeMixed_12min.wav';
    audiowrite(outFile, mixedBuffer, fs);
    fprintf('已保存混合结果到 "%s".\n', outFile);
end

%% ====== 辅助函数: 循环读取噪声 ======
function frame = getNoiseFrame(noiseData, pointer, frameSize)
    lenN = length(noiseData);
    endPos = pointer + frameSize - 1;
    if endPos <= lenN
        frame = noiseData(pointer:endPos);
    else
        chunk1 = noiseData(pointer:end);
        leftover = frameSize - length(chunk1);
        chunk2 = noiseData(1:leftover);
        frame = [chunk1; chunk2];
    end
end

%% ====== 辅助函数: 打印噪声模式 ======
function t = noiseModeText(dbVal)
    if isnan(dbVal)
        t = 'No Noise';
    else
        t = sprintf('%g dB', dbVal);
    end
end
