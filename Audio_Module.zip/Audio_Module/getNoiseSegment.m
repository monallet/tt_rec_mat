%% Local Function: get a continuous noise segment
function [segment, newPointer] = getNoiseSegment(noiseData, pointer, segmentLength)
    dataLength = length(noiseData);
    segment = zeros(segmentLength, 1);
    samplesCollected = 0;
    newPointer = pointer;
    
    while samplesCollected < segmentLength
        remaining = segmentLength - samplesCollected;
        if newPointer + remaining - 1 <= dataLength
            segment(samplesCollected+1 : samplesCollected+remaining) = noiseData(newPointer:newPointer+remaining-1);
            newPointer = newPointer + remaining;
            samplesCollected = samplesCollected + remaining;
        else
            samplesToEnd = dataLength - newPointer + 1;
            segment(samplesCollected+1 : samplesCollected+samplesToEnd) = noiseData(newPointer:end);
            samplesCollected = samplesCollected + samplesToEnd;
            newPointer = 1; % Wrap around
        end
    end
end