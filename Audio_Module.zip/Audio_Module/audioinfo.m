InitializePsychSound()
ss = audioDeviceReader;
info = getAudioDevices(ss);
fs = ss.SampleRate;
disp(info)
disp(fs)