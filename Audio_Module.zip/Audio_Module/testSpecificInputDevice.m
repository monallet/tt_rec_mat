function testSpecificInputDevice(deviceID)
    % testSpecificInputDevice tests an audio input device using PsychPortAudio.
    %
    % It records audio from the specified input device for a set duration and
    % then plots the accumulated waveform.
    %
    % Usage:
    %   testSpecificInputDevice(1)
    
    % Initialize PsychSound in low-latency mode.
    InitializePsychSound();
    
    % Define audio parameters.
    fs = 44100;             % Sampling rate (Hz)
    nChannels = 1;          % Mono recording
    recordDuration = 5;     % Duration of recording (seconds)
    buffersize = 4096;      % Maximum allowed buffer size (0 to 4096 samples)
    
    % Open the specified device in capture mode (mode 2).
    % reqlatencyclass of 1 tries to achieve low latency.
    pahandle = PsychPortAudio('Open', deviceID, 2, 1, fs, nChannels, buffersize);
    PsychPortAudio('GetAudioData', pahandle, 1*60);
    % Start recording continuously (0 repetitions means record until stopped).
    PsychPortAudio('Start', pahandle, 0, 0, 1);
    fprintf('Recording from device %d for %d seconds...\n', deviceID, recordDuration);
    
    % Prepare a variable to accumulate the recorded data.
    recordedAudio = [];
    startTime = GetSecs;
    
    % Poll the device repeatedly during the record duration.
    pollInterval = 0.1; % seconds
    while (GetSecs - startTime) < recordDuration
        WaitSecs(pollInterval);
        % Retrieve any available audio data.
        [newData, nSamples] = PsychPortAudio('GetAudioData', pahandle);
        if nSamples > 0
            % Ensure newData is a row vector.
            newData = newData(:).';
            % Accumulate the new samples.
            recordedAudio = [recordedAudio, newData];
        end
    end


    targetDir = 'Data';
    filePath = fullfile(targetDir, 'testSound.wav');
    
    % Write the audio files to the specified directory
    audiowrite(filePath, recordedAudio, fs);
    disp('Audio recordings saved.');

    % Stop recording.
    PsychPortAudio('Stop', pahandle);
    fprintf('Recording complete. Accumulated %d samples.\n', length(recordedAudio));
    
    % Plot the recorded waveform.
    figure;
    plot(recordedAudio);
    title(sprintf('Recorded Audio Waveform from Device %d', deviceID));
    xlabel('Sample Number');
    ylabel('Amplitude');
    
    % Close the audio device.
    PsychPortAudio('Close', pahandle);
    fprintf('Audio input test for device %d completed.\n', deviceID);
end



% testWhichAudioDevice
% --- Available Audio Devices ---
% Device 0: Microsoft Sound Mapper - Input (Input Ch: 2, Output Ch: 0)
% Device 1: Microphone (HD Pro Webcam C920) (Input Ch: 2, Output Ch: 0)
% Device 2: Analog (9+10) (RME UFX II) (Input Ch: 2, Output Ch: 0)
% Device 3: Analog (1+2) (RME UFX II) (Input Ch: 2, Output Ch: 0)
% % % Device 4: Microsoft Sound Mapper - Output (Input Ch: 0, Output Ch: 2)
% % % Device 5: Speakers (RME UFX II) (Input Ch: 0, Output Ch: 2)
% % % Device 6: Analog (9+10) (RME UFX II) (Input Ch: 0, Output Ch: 2)
% % % Device 7: Analog (9+10) (RME UFX II) (Input Ch: 0, Output Ch: 2)
% Device 8: Speakers (RME UFX II) (Input Ch: 0, Output Ch: 2)
% Device 9: Analog (9+10) (RME UFX II) (Input Ch: 2, Output Ch: 0)
% Device 10: Microphone (HD Pro Webcam C920) (Input Ch: 2, Output Ch: 0)
% Device 11: Analog (1+2) (RME UFX II) (Input Ch: 2, Output Ch: 0)
% Device 12: Analog (9+10) (RME UFX II) [Loopback] (Input Ch: 2, Output Ch: 0)
% Device 13: Speakers (RME UFX II) [Loopback] (Input Ch: 2, Output Ch: 0)
% Device 14: FrontMic (Realtek HD Audio Front Mic input) (Input Ch: 2, Output Ch: 0)
% % % Device 15: Headphones (Realtek HD Audio 2nd output) (Input Ch: 0, Output Ch: 2)
% % % Device 16: Speakers (Realtek HD Audio output) (Input Ch: 0, Output Ch: 2)
% Device 17: Stereo Mix (Realtek HD Audio Stereo input) (Input Ch: 2, Output Ch: 0)
% % % Device 18: Output (AMD HD Audio HDMI out #0) (Input Ch: 0, Output Ch: 2)
% % % Device 19: Output (AMD HD Audio HDMI out #3) (Input Ch: 0, Output Ch: 2)
% % % Device 20: Analog (9+10) (MADIface Analog (9+10)) (Input Ch: 0, Output Ch: 2)
% Device 21: Analog (9+10) (MADIface Analog (9+10)) (Input Ch: 2, Output Ch: 0)
% % % Device 22: Analog (1+2) (MADIface Analog (1+2)) (Input Ch: 0, Output Ch: 2)
% Device 23: Analog (1+2) (MADIface Analog (1+2)) (Input Ch: 2, Output Ch: 0)
% Device 24: Microphone (HD Pro Webcam C920) (Input Ch: 2, Output Ch: 0)
% --------------------------------