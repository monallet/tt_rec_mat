function runNoiseEvents(totalDuration, numCycleEvents, noiseLogDir, experimentID, playDeviceID1, playDeviceID2, noiseFile)
% runNoiseEvents plays randomized noise events asynchronously.
%   totalDuration   - Total duration for noise playback (in seconds)
%   numCycleEvents  - Number of noise events within the total duration
%   targetDir       - Directory where the noise log will be saved
%   experimentID    - Experiment identifier (used in log filenames)
%   playDeviceID1, playDeviceID2 - Device IDs for the noise playback channels
%   noiseFile       - Path to the noise audio file (e.g., 'pink_noise_44k1.wav')

%% 0. Set System Volume (Windows only)
try
    system('nircmd.exe setsysvolume 32768');
    fprintf('System volume set to 50%% using nircmd.\n');
catch
    warning('Unable to set system volume. Please adjust manually if needed.');
end

%% 1. Audio Settings
fs = 48000; 
eventDuration = totalDuration / numCycleEvents;

% (Uncomment if you have an initialiseSoundDevices function)
% initialiseSoundDevices;

% Open audio playback devices for noise events:
playHandle1 = PsychPortAudio('Open', playDeviceID1, 1, 1, fs, 1);
playHandle2 = PsychPortAudio('Open', playDeviceID2, 1, 1, fs, 1);

% Load and prepare the noise file
[noiseRaw, fsNoise] = audioread(noiseFile);
if size(noiseRaw,2) > 1
    noiseRaw = mean(noiseRaw, 2);
end
if fsNoise ~= fs
    noiseRaw = resample(noiseRaw, fs, fsNoise);
end

%% 2. Randomised Event Levels
% Levels: 72 dB, 78 dB, and NaN (to indicate silence)
levelsArray = repmat([72, 78, NaN], 1, ceil(numCycleEvents/3));
levelsArray = levelsArray(1:numCycleEvents);
cycleLevels = levelsArray(randperm(numCycleEvents));

% Structure to store event information (for logging)
cycleEvents = struct('start', [], 'end', [], 'level', []);
for i = 1:numCycleEvents
    cycleEvents(i).start = (i-1)*eventDuration;
    cycleEvents(i).end = i*eventDuration;
    cycleEvents(i).level = cycleLevels(i);
end

%% 3. Loop through Noise Events
noisePointer = 1;
refPressure = 20e-6; 
% trigger_port = config_io();  % Assumes config_io() is defined to return the trigger port handle

for evt = 1:numCycleEvents
    currentTime = (evt-1) * eventDuration;
    currentLevel = cycleEvents(evt).level;
    
    if isnan(currentLevel)
        fprintf('Event %d (Time: %.2f - %.2f s): No noise (silent event).\n', evt, currentTime, currentTime+eventDuration);
    else
        fprintf('Event %d (Time: %.2f - %.2f s): Playing %g dB noise.\n', evt, currentTime, currentTime+eventDuration, currentLevel);
    end
    drawnow;
    
    % SendTrig(trigger_port, 101);  % Trigger at event start
    
    segmentLength = round(eventDuration * fs);
    [noiseSegment, noisePointer] = getNoiseSegment(noiseRaw, noisePointer, segmentLength);
    
    % If the event is silent, replace with zeros
    if isnan(currentLevel)
        noiseSegment = zeros(segmentLength, 1);
    else
        desiredRMS = refPressure * 10^(currentLevel/20);
        currentRMS = rms(noiseSegment);
        if currentRMS < 1e-12
            noiseSegment = desiredRMS * randn(segmentLength, 1);
        else
            noiseSegment = noiseSegment * (desiredRMS / currentRMS);
        end
    end
    
    % Fill the buffers and start playback asynchronously
    PsychPortAudio('FillBuffer', playHandle1, noiseSegment');
    PsychPortAudio('FillBuffer', playHandle2, noiseSegment');
    PsychPortAudio('Start', playHandle1, 1, 0, 1);
    PsychPortAudio('Start', playHandle2, 1, 0, 1);
    
    % SendTrig(trigger_port, 102);  % Trigger at event end
    
    % Wait for the duration of the event before next iteration
    WaitSecs(eventDuration);
end

%% 4. Stop Playback and Clean Up
PsychPortAudio('Stop', playHandle1, 1); 
PsychPortAudio('Stop', playHandle2, 1); 
PsychPortAudio('Close', playHandle1);
PsychPortAudio('Close', playHandle2);

%% 5. Save Noise Event Log
NoiseLog = fullfile(noiseLogDir, sprintf('p142_%s_3AB_noise_event.txt', experimentID));
fid = fopen(NoiseLog, 'w');
if fid == -1
    warning('Unable to open %s for writing.', NoiseLog);
else
    fprintf(fid, 'Event Order:\n');
    fprintf(fid, 'Event\tStart_Time(s)\tEnd_Time(s)\tdB_Level\n');
    for evt = 1:numCycleEvents
        fprintf(fid, '%d\t%.2f\t%.2f\t', evt, cycleEvents(evt).start, cycleEvents(evt).end);
        if isnan(cycleEvents(evt).level)
            fprintf(fid, 'NaN\n');
        else
            fprintf(fid, '%g\n', cycleEvents(evt).level);
        end
    end
    fclose(fid);
end

end

%% --- Helper Function: getNoiseSegment ---
function [segment, newPointer] = getNoiseSegment(noiseRaw, pointer, segmentLength)
    totalLength = length(noiseRaw);
    if pointer + segmentLength - 1 <= totalLength
        segment = noiseRaw(pointer:pointer+segmentLength-1);
        newPointer = pointer + segmentLength;
    else
        % Wrap around if needed
        remainder = totalLength - pointer + 1;
        segment = [noiseRaw(pointer:end); noiseRaw(1:(segmentLength - remainder))];
        newPointer = segmentLength - remainder + 1;
    end
end
