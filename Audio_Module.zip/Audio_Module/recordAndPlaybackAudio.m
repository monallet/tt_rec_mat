function recordAndPlaybackAudio(audioData, fs, csvFilename)
% recordAndPlaybackAudio plays back the recorded audio and records external
% button press events for synchronization. The experimenter confirms playback 
% start via the external button, and during playback the participant's button
% press/release events are recorded. Finally, the data are saved to a CSV file.
%
%   audioData  - Recorded audio data.
%   fs         - Sampling frequency.
%   csvFilename- Filename for saving sync responses (CSV format).

    disp('=== Audio Playback & Sync Recording Module ===');
    disp('Experimenter: Press the external button to start audio playback.');
    % Wait for the experimenter’s confirmation (using external button).
    KbWait([], 2);
    
    % Start audio playback and record the playback start time.
    disp('Playing back audio...');
    playbackStartTime = GetSecs;
    sound(audioData, fs);
    
    % Calculate audio duration in seconds.
    audioDuration = length(audioData) / fs;
    
    % Record the sync responses (button press intervals) during audio playback.
    syncResponses = recordSyncResponses(playbackStartTime, audioDuration);
    
    % Write the collected sync responses to a CSV file.
    writeSyncResponsesToCSV(syncResponses, csvFilename);
end

%% ------------------------------------------------------------------------
function syncResponses = recordSyncResponses(playbackStartTime, audioDuration)
% recordSyncResponses continuously polls the external button (assumed to be
% the 'space' key) during audio playback to record intervals when the button 
% is held down (interpreted as "sync"). It then computes the complementary 
% intervals ("out") and returns a complete list of intervals.
%
%   playbackStartTime - Timestamp when playback started (from GetSecs).
%   audioDuration     - Duration of the audio in seconds.
%
%   syncResponses     - Cell array with rows: {start_time, end_time, state}

    % Define polling interval (in seconds) and key of interest.
    pollInterval = 0.01;
    keyOfInterest = KbName('space');  % Change if a different key is used.
    
    % Initialize variables for recording intervals.
    syncIntervals = []; % Will store rows [start, end] for "sync" periods.
    responseIdx = 1;
    wasPressed = false;
    currentIntervalStart = [];
    
    disp('Recording sync responses: Press and hold the external button when in sync.');
    t0 = playbackStartTime;
    currentTime = GetSecs;
    
    % Continue polling until the audio playback duration is reached.
    while (currentTime - t0) < audioDuration
        [keyIsDown, keyTime, keyCode] = KbCheck;
        if keyIsDown && keyCode(keyOfInterest)
            % If the button is pressed and it was not already pressed, record start.
            if ~wasPressed
                wasPressed = true;
                currentIntervalStart = keyTime;
            end
        else
            % If the button is released after being pressed, record the interval.
            if wasPressed
                wasPressed = false;
                intervalStart = currentIntervalStart;
                intervalEnd = GetSecs;
                syncIntervals(responseIdx, :) = [intervalStart, intervalEnd];
                responseIdx = responseIdx + 1;
            end
        end
        pause(pollInterval);
        currentTime = GetSecs;
    end
    
    % If button is still held at the end of playback, close the interval.
    if wasPressed
        intervalStart = currentIntervalStart;
        intervalEnd = playbackStartTime + audioDuration;
        syncIntervals(responseIdx, :) = [intervalStart, intervalEnd];
    end
    
    % Convert absolute timestamps to relative times (with respect to playbackStartTime).
    syncIntervals = syncIntervals - playbackStartTime;
    
    % Build a complete timeline with both sync and out intervals.
    % Each row will be: {start, end, state}, where state is 'sync' or 'out'.
    fullResponses = {};
    fullIdx = 1;
    lastTime = 0;
    
    % For each sync interval, add an "out" period if there is a gap.
    for i = 1:size(syncIntervals,1)
        startSync = syncIntervals(i,1);
        endSync   = syncIntervals(i,2);
        if startSync > lastTime
            % Interval when button was not pressed ("out")
            fullResponses{fullIdx,1} = lastTime;
            fullResponses{fullIdx,2} = startSync;
            fullResponses{fullIdx,3} = 'out';
            fullIdx = fullIdx + 1;
        end
        % Add the "sync" interval.
        fullResponses{fullIdx,1} = startSync;
        fullResponses{fullIdx,2} = endSync;
        fullResponses{fullIdx,3} = 'sync';
        fullIdx = fullIdx + 1;
        lastTime = endSync;
    end
    % If there is remaining time after the last sync interval, mark it as "out".
    if lastTime < audioDuration
        fullResponses{fullIdx,1} = lastTime;
        fullResponses{fullIdx,2} = audioDuration;
        fullResponses{fullIdx,3} = 'out';
    end
    
    syncResponses = fullResponses;
    disp('Sync response recording complete.');
end

%% ------------------------------------------------------------------------
function writeSyncResponsesToCSV(syncResponses, csvFilename)
% writeSyncResponsesToCSV writes the sync response intervals to a CSV file.
% Each line in the file has the format:
%   HH:MM:SS:FF-HH:MM:SS:FF, state
% where 'FF' denotes frames (assuming 24 frames per second).

    frameRate = 24;  % Frame rate for timecode conversion.
    fid = fopen(csvFilename, 'w');
    if fid == -1
        error('Cannot open file: %s', csvFilename);
    end
    
    % Write each interval in the specified format.
    for i = 1:size(syncResponses,1)
        startSec = syncResponses{i,1};
        endSec   = syncResponses{i,2};
        state    = syncResponses{i,3};
        startCode = secondsToTimecode(startSec, frameRate);
        endCode   = secondsToTimecode(endSec, frameRate);
        fprintf(fid, '%s-%s, %s\n', startCode, endCode, state);
    end
    fclose(fid);
    disp(['Sync responses saved to ', csvFilename]);
end

%% ------------------------------------------------------------------------
function timecode = secondsToTimecode(secondsVal, frameRate)
% secondsToTimecode converts a time in seconds to a timecode string of the 
% format HH:MM:SS:FF, where FF are frames.

    hours = floor(secondsVal / 3600);
    minutes = floor(mod(secondsVal, 3600) / 60);
    secs = floor(mod(secondsVal, 60));
    frames = floor((secondsVal - floor(secondsVal)) * frameRate);
    timecode = sprintf('%02d:%02d:%02d:%02d', hours, minutes, secs, frames);
end