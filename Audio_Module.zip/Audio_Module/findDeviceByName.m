function deviceID = findDeviceByName(targetName, devices, channelType)
    % findDeviceByName searches the devices structure (from PsychPortAudio('GetDevices'))
    % for a device whose name matches targetName (case-insensitive) and which has at least
    % one channel of the specified type ('input' or 'output').
    % It returns the actual device ID as stored in the device structure (which may be 0).
    
    deviceID = [];
    for i = 1:length(devices)
        % Retrieve the device name, supporting different field names:
        if isfield(devices(i), 'deviceName')
            currentName = devices(i).deviceName;
        else
            currentName = devices(i).DeviceName;
        end
        
        if strcmpi(currentName, targetName)
            % Retrieve the actual device ID:
            if isfield(devices(i), 'deviceid')
                currID = devices(i).deviceid;
            else
                currID = devices(i).DeviceIndex;
            end
            
            % Check if the device has the required channel(s):
            if strcmpi(channelType, 'input') && devices(i).NrInputChannels > 0
                deviceID = currID;
                return;
            elseif strcmpi(channelType, 'output') && devices(i).NrOutputChannels > 0
                deviceID = currID;
                return;
            end
        end
    end
    
    if isempty(deviceID)
        error('Device "%s" with %s channels not found.', targetName, channelType);
    end
end