% Audio_Recording.m
% Module to manage audio recording and playback using MATLAB’s audio functions
% and Psychtoolbox for external button responses.

function audioRecorder = initializeAudio()
    % Set up the audio recorder.
    disp('Initializing audio recorder...');
    fs = 44100;      % Sampling rate (Hz)
    nBits = 16;      % Bit depth
    nChannels = 1;   % Mono recording
    audioRecorder = audiorecorder(fs, nBits, nChannels);
    audioRecorder.fs = fs;  % Save the sampling rate
end

function startAudioRecording(audioRecorder)
    % Begin audio capture.
    disp('Starting audio recording...');
    record(audioRecorder);
end

function [audioData, fs] = stopAudioRecording(audioRecorder)
    % Stop recording and return the captured audio data.
    disp('Stopping audio recording...');
    stop(audioRecorder);
    audioData = getaudiodata(audioRecorder);
    fs = audioRecorder.fs;
end

% function playbackAudio(audioData, fs)
%     % Play back the recorded audio.
%     disp('Playing back recorded audio...');
%     sound(audioData, fs);
% end
% 
% function syncResponses = recordSyncResponses()
%     % Record external button press events during audio playback using Psychtoolbox.
%     % The participant is instructed to press and hold the external button when in sync.
%     disp('Recording synchronization responses...');
%     disp('Press and hold the designated button when in sync, and release when not.');
% 
%     % Wait for the button press (record start timestamp)
%     [~, tStart, ~] = KbWait([], 2);
%     % Wait for the button release (record end timestamp)
%     [~, tEnd, ~] = KbWait([], 2);
% 
%     syncResponses.timestamps = [tStart, tEnd];
%     disp('Synchronization responses recorded.');
% end