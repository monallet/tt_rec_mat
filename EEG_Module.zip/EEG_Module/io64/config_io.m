function trigger_port = config_io(address)

trigger_port.ioObj = io64();

if ~exist('address','var') || isempty(address)
  trigger_port.address = hex2dec('3FE8');
elseif isa(address, char)
    trigger_port.address = hex2dec(address);
else
    error("Input address wrong type.  Should be Char!")
end
%install the inpoutx64.dll driver
%status = 0 if installation successful
trigger_port.status = io64(trigger_port.ioObj);
if(trigger_port.status ~= 0)
    error('Trigger port installation failed!')
end

io64(trigger_port.ioObj, trigger_port.address, 0);
end