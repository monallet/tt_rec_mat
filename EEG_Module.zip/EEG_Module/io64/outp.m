function outp(address,byte)

global trigger_port;

%test for correct number of input arguments
if(nargin ~= 2)
    error('usage: outp(address,data)');
end

io64(trigger_port.ioObj,address,byte);
