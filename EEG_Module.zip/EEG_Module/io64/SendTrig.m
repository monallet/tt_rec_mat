function SendTrig(trigger_port, n)
    io64(trigger_port.ioObj, trigger_port.address, n);
    WaitSecs(0.05);
    io64(trigger_port.ioObj, trigger_port.address, 0);
end