%% 0. Initilise Eyelink
initialiseEyelink;
% also add experimentID, phaseID for the experiment and its corresponding blocks for saving and identificaiton

%% 1. Calibration and acceptance validation
eyeCalib;
calibrationStatus = waitForCalibrationAcceptance();
if strcmp(calibrationStatus, 'accepted')
    disp('Calibration done.');
    WaitSecs(pollInterval);
else
    disp('Calibration failed.');
end

%% 2. After acceptance of calibration result, initilise the save function then start recording
eyeSave(targetDir, experimentID, phaseID);
Eyelink('StartRecording');
Eyelink('Message', ('REC100')); 

% experiment script shows here...

%% 3. Pause the recording and do drift check within block (optional)
SendTrig(trigger_port, 200);
Eyelink('Message','!V DRIFT_CORRECTING');
% Eyelink('StopRecording'); % pause recording

% Guidance on-screen
calibText = ['We can have a short break and the re-calibration/drift correction will shortly start.\n\n' ...
             'Please wait still until the dots show on the screen.'];
DrawFormattedText(winMain, calibText, 'center', 'center', whiteMain);
Screen('Flip', winMain);
KbWaitForShift();

WaitSecs(0.1);
EyelinkDoDriftCorrect(el);  
WaitSecs(0.1); 
Eyelink('Message','!V DRIFT_CORRECTED');

% Eyelink('StartRecording'); % resume recording
WaitSecs(0.1);
SendTrig(trigger_port, 201);
Eyelink('Message','REC201');

% experiment script continues here...

%% 4. Send the triggers, stop the recording and save it as .edf file in the host machine
Eyelink('Message', ('END100')); 
WaitSecs(pollInterval);
SendTrig(trigger_port, 255)
WaitSecs(0.5);

Eyelink('StopRecording');
Eyelink('CloseFile');
disp('Eyelink recording saved.');

%% X. Trigger naming guidance
Eyelink('Message', ('REC100'));             % mark the start of the recording
Eyelink('Message','!V DRIFT_CORRECTING');   % mark the start of drift correction in the recording
Eyelink('Message','!V DRIFT_CORRECTED');    % mark the completion of drift correction in the recording
Eyelink('Message','REC201');                % mark the resume of recording, both applicable whether paused. For better alignment, we suggest no pausing during correction.
Eyelink('Message', ('END100'));             % mark the end of the recording and return a file as .edf
SendTrig(trigger_port, 200);                % mark the re_calibration/drift correction for EEG signal
SendTrig(trigger_port, 201);                % mark the resume of Eyelink recording for EEG signal, both applicable whether paused.





