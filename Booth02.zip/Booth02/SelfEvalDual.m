% SelfEvalDual.m
%
% This script implements Windows 19-23 of the experiment for the self-evaluation block:
%
% Author: [Moana Chen]
% Date: [25.02.2025]

%% Window 19: Self-Evaluation Instructions & Dynamic Playback
pollInterval = 0.01;
selfEvalInstr = ['Part 4: \n\n' ...
                 'Now we are performing the self-evaluation part.\n\n' ...
                 'You will listen to an audio recording of your conversation.\n' ...
                 'While listening, answer this question:\n\n' ...
                 '<How good of the timing with the speaker transition at this moment, is the flow smooth currently?>\n\n' ...
                 'If you feel connected, press and hold the external button until you no longer feel so.\n' ...
                 'Press and hold again if you feel connected later.\n\n' ...
                 'Press the button to begin this part.'];

DrawFormattedText(winMain, selfEvalInstr, 'center', 'center', whiteMain);
Screen('Flip', winMain);    

KbWaitForShift();
WaitSecs(0.5);

%% Window 20
fileA = fullfile(targetDir, sprintf('p142_%s_2A.wav', experimentID));
fileB = fullfile(targetDir, sprintf('p142_%s_2B.wav', experimentID));

[audioDataA2, fs_A] = audioread(fileA);
[audioDataB2, fs_B] = audioread(fileB);

if fs_A == fs_B
    mixed_track = mixStereoWaveforms(audioDataA2, audioDataB2);
    audioData = mixed_track;
    fs = fs_A;
else
    error('Sampling rates do not match between the two audio files.');
end

% % If stereo, convert to mono by averaging channels. % here we draw the full mixed track, and the seperated
if size(audioData,2) > 1, audioData = mean(audioData,2); end
if size(audioDataA2,2) > 1, audioDataA2 = mean(audioDataA2,2); end
if size(audioDataB2,2) > 1, audioDataB2 = mean(audioDataB2,2); end

audioDuration = length(mixed_track) / fs;

% Prepare downsampled data for drawing a static waveform background.
downsampleFactor = 100;  % For faster drawing
audioDataDown = audioData(1:downsampleFactor:end);
numPoints = length(audioDataDown);

margin = 100;  % left-right margin for waveform
xVals1 = linspace(margin, rectMain(3) - margin, numPoints);
amplitudeScale = 200;  % vertical scale for the wave
yCenter1 = rectMain(4) / 2;
yVals1 = yCenter1 + (audioDataDown * amplitudeScale);

% downsample each track separately for drawing:
downsampleFactor = 100;
audioDataDownA = audioDataA2(1:downsampleFactor:end);
audioDataDownB = audioDataB2(1:downsampleFactor:end);
numPoints = min(length(audioDataDownA), length(audioDataDownB));
audioDataDownA = audioDataDownA(1:numPoints);
audioDataDownB = audioDataDownB(1:numPoints);

margin = 100;
xVals = linspace(margin, rectMain(3)-margin, numPoints);

% two vertical centers for drawing:
delta = 30; % this value for the desired spacing. (50 for separate)
yCenter_up = rectMain(4)/2 - delta;
yCenter_down = rectMain(4)/2 + delta;
amplitudeScale = 200;
yValsA = yCenter_up + (audioDataDownA * amplitudeScale);
yValsB = yCenter_down + (audioDataDownB * amplitudeScale);

% open two playback handles:
pahandleA = PsychPortAudio('Open', playDeviceID1, 1, 1, fs, 1);
pahandleB = PsychPortAudio('Open', playDeviceID2, 1, 1, fs, 1);
PsychPortAudio('FillBuffer', pahandleA, audioData');
PsychPortAudio('FillBuffer', pahandleB, audioData');    

% show waveform and prompt to start playback
Screen('FillRect', winMain, [255,255,255]);
drawWaveform(winMain, xVals, yValsA, [0,255,0]);   % [255,0,0] red, or [0, 255, 0] green for track A (upper)
drawWaveform(winMain, xVals, yValsB, [255,0,0]);    % [0,0,255] blue for track B (lower)

playbackinst = ['Please answer this question during the playback: \n\n' ...
                '<How good of the timing with the speaker transition at this moment, is the flow smooth currently?> \n\n' ...
                'If you feel positive, press and hold the external key on your right hand until you feel no more. \n\n' ...
                'Press and hold again if you feel connected again during the conversation. \n' ...
                'If you are ready, press the external key to start playback and your evaluation.\n\n'];

% for booth A
DrawFormattedText(winMain, playbackinst, 'center', 50, [0,0,0]);
Screen('Flip', winMain);

while true
    [keyIsDown, ~, keyCode] = KbCheck;
    if keyIsDown && keyCode(KbName('Space'))
        break;
    end
    WaitSecs(0.01);
end
playbackStartTime = GetSecs;

% Start playback on booth A's channel.
PsychPortAudio('Start', pahandleA, 1, 0, 1);
PsychPortAudio('Start', pahandleB, 1, 0, 1);
disp('Audio playback started for self-evaluation.');

% syncResponses = recordSelfEvalResponsesAndDraw(winMain, xVals1, yVals1, playbackStartTime, audioDuration, 'space');
syncResponses = recordSelfEvalResponsesAndDrawDual(winMain, xVals, yValsA, yValsB, playbackStartTime, audioDuration, 'Space', [0,255,0], [255,0,0]);

PsychPortAudio('Stop', pahandleA);
PsychPortAudio('Close', pahandleA);

PsychPortAudio('Stop', pahandleB);
PsychPortAudio('Close', pahandleB);
 
%% save intervals to CSV
csvFilename_A = fullfile(targetDir, sprintf('p142_%s_selfeval_A.csv', experimentID));
writeSyncResponsesToCSV(syncResponses, csvFilename_A);

