%% MainExperiment.m
%
% This script implements the whole experiment:
%
% Author: [Moana Chen]
% Date: [06.03.2025]
 

%% experiment path load
addpath("Main/")
addpath("Data/")
addpath("EEG_Module/")
addpath("Eyelink_Module/")

try
    
    % % Start parallel pool with 2 w or kers (if not already started)
    % if isempty(gcp('nocreate'))
    %     parpool(2);
    % end
    
    %% setup window
    % retrieve all screens
    screens = Screen('Screens'); 
    % if length(screens) < 2
    %     error('Only one screen detected. Make sure your external monitor is set to extended desktop.');
    % end
    
    mainScreen = min(screens);      % e.g., external monitor 1 in booth 2 (screen 1)
    % externalScreen = max(screens);  % e.g., external monitor 2 in booth 3 (screen 1), 
    externalScreen = min(screens); % only for tests with one monitor

    % open a window on each screen
    [winMain, rectMain] = Screen('OpenWindow', mainScreen, WhiteIndex(mainScreen));   % Black/dark gray background
    [winExt, rectExt] = Screen('OpenWindow', externalScreen, WhiteIndex(externalScreen));

    % set a high text resolution on each window (increase Tex tSize as needed)
    Screen('TextSize', winMain, 28);
    Screen('TextSize', winExt, 28);

    whiteMain = BlackIndex(mainScreen); 
    whiteExt = BlackIndex(externalScreen);
    
    %% setup cam
    % cam1 = webcam("FaceTime HD Camera");
    % cam2 = webcam("OBS Virtual Camera");
    
    %% setup audio input
    % Initialize PsychPortAudio sound driver:
    stim.audio.latLev = 1; 
    rec.reqLatencyClass = 1; 
    rec.mode = 2; %1==sound playback only; 2 == audio capture
    nBits = 16; % Bit depth
    nChannels = 2; %number of channels
    fs_audio = 44100;
    rec.repetitions = 1; %0:infinite repetitions, ie.,until manually stopped via the ‘Stop’ subfunction
    rec.when = 0; %starttime of playback: 0: immediately
    rec.waitForStart = 1; % wait for sound onset (to speakers) to register startTime?
    rec.amountToAllocateSecs = 4*60; % in seconds

    recordDeviceID1 = 1; 
    recordDeviceID2 = 0; 

    %% setup audio output
    playDeviceID1 = 4;
    playDeviceID2 = 5;

    %% Measurement starts here

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % %% RestingState measurement
    % fprintf('Starting RestingState measurement...\n');
    % try
    %     RestingState;
    %     fprintf('RestingState measurement completed successfully.\n');
    % catch ME
    %     fprintf('Error during RestingState: %s\n', ME.message);
    % end
    
    %% TurnTakingInduction block
    % fprintf('Starting TurnTakingInduction block...\n');
    % try
    %     TurnTakingInduction;
    %     fprintf('TurnTakingInduction block completed successfully.\n');
    % catch ME
    %     fprintf('Error during TurnTakingInduction: %s\n', ME.message);
    % end

    %% NaturConv block
    fprintf('Starting NaturConv block...\n');
    try
        NaturConv;
        fprintf('NaturConv block completed successfully.\n');
    catch ME
        fprintf('Error during NaturConv: %s\n', ME.message);
    end
     
    %% SelfEval block
    fprintf('Starting Self Evaluation block...\n');
    try
        SelfEval;
        fprintf('Self Evaluation block completed successfully.\n');
    catch ME
        fprintf('Error during Self Evaluation: %s\n', ME.message);
    end
     
    %% Questionnaire block
    fprintf('Starting Questionnair collection...\n');
    try
        Questionnair;
        fprintf('Questionnair collection completed successfully.\n');
    catch ME
        fprintf('Error during Questionnair: %s\n', ME.message);
    end

    %% Close the experiment window
    KbWaitForShift();
    Screen('CloseAll');
    
catch ME
    Screen('CloseAll');
    rethrow(ME);
end

