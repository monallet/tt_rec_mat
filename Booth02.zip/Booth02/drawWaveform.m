%% This is the function drawing the waveform of audio
% Author: [Moana Chen]
% Date: [25.02.2025]

function drawWaveform(win, xVals, yVals, lineColor)
    % drawWaveform draws a line connecting points defined by xVals and yVals using the specified lineColor.
    if nargin < 4
        lineColor = [0, 255, 0];  % default green
    end
    for i = 1:length(xVals)-1
        Screen('DrawLine', win, lineColor, xVals(i), yVals(i), xVals(i+1), yVals(i+1), 2);
    end
end


% %% Local Function drawWaveform for disp
% function drawWaveform(win, xVals, yVals, color)
%     % Draws a waveform line with the specified color.
%     for i = 1:length(xVals)-1
%         Screen('DrawLine', win, color, xVals(i), yVals(i), xVals(i+1), yVals(i+1), 2);
%     end
% end