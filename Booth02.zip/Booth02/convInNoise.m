% convInNoise.m
%
% This script implements the conversation in noise for the experiment:
%
% Author: [Moana Chen]
% Date: [27.03.2025]

%% Window 15: Conversation instructions & Participant readiness
pollInterval = 0.01;
convInstr = ['Part 3: \n\n' ...
             'Now you are on part three of this experiment.\n\n' ...
             'Both of you will contunue a conversation for 12 minutes on the topic. \n' ...
             'This time you will hear some noise during conversation.\n\n' ...
             'Please keep your voice normal and keep your head and body still except for your articulatory organs.\n\n' ...
             'When both of you are ready, we will resume the recordings.\n'];

DrawFormattedText(winMain, convInstr, 'center', 'center', whiteMain);
Screen('Flip', winMain);
KbWaitForShift();
WaitSecs(0.5);

expChoice = questdlg('Both participants are ready. Please confirm the beginning of the conversational measurement.', ...
                     'Experimenter Confirmation', ...
                     'Confirm', 'Cancel', 'Confirm');
if ~strcmp(expChoice, 'Confirm')
    error('Experimenter cancelled the measurement.');
end
WaitSecs(0.5);

%% Window 16: Topic introduction (1-minute familiarisation)
topicText = ['Now you have 15 seconds to get familiar with the previous topic you are going to discuss further:\n\n\n' ...
             '- You can start conversation on the quality of your daily life from different aspects, \n' ...
             'e.g., sleep, nutrition, work, partnership, hobby. \n\n' ...
             '- You can also share personal experiences that specifically changed the quality of your everyday life, \n' ...
             'such as how you overcame the difficulties in your daily life, e.g., nutritional problems, sleep, working habits etc. \n\n' ...
             '- Feel free to propose self-improvement techniques like meditation, sports, physical training, leisure, and travelling. \n\n\n' ...
             'This is just a proposal to initiate your conversation, you can always drift in other topics if it maintains your interest. \n' ...
             'You can also always go back to the initiated topics.\n\n' ...
             'You could begin with greeting and then proceed to the topics together.\n\n' ];

DrawFormattedText(winMain, topicText, 'center', 'center', whiteMain);
Screen('Flip', winMain);

KbName('UnifyKeyNames');
shiftKeys = [KbName('LeftShift'), KbName('RightShift')];
startTime = GetSecs;
while (GetSecs - startTime) < 15
    [keyIsDown, ~, keyCode] = KbCheck;
    if keyIsDown && any(keyCode(shiftKeys))
        break;
    end
    WaitSecs(0.01);
end

%% Window 17: Live Conversation Measurement with Video Streaming
headerText = ['Conversational Measurement in Progress... \n\n' ...
              'You can continue conversation on the quality of your daily life from different aspects,\n' ...
              'e.g., sleep, nutrition, work, partnership, hobby... \n' ...
              'And you can explore more topics during the talk with each other if it maintains your interest. \n\n'];

%% load audiorecorder objects
recObjA3 = PsychPortAudio('Open', recordDeviceID1, 2, 1, fs_audio, nChannels, buffersize);
recObjB3 = PsychPortAudio('Open', recordDeviceID2, 2, 1, fs_audio, nChannels, buffersize);

KbWaitForShift();

PsychPortAudio('GetAudioData', recObjA3, rec.amountToAllocateSecs);
PsychPortAudio('GetAudioData', recObjB3, rec.amountToAllocateSecs);

buffer1 = []; % for booth 1 microphone
buffer2 = []; % for booth 2 microphone

% start the recording
PsychPortAudio('Start', recObjA3, rec.repetitions, rec.when, rec.waitForStart);
PsychPortAudio('Start', recObjB3, rec.repetitions, rec.when, rec.waitForStart);

%% trigger sending for start
Eyelink('Message', ('REC100')); 
WaitSecs(pollInterval);
SendTrig(trigger_port, 100)

%% start noise playback, this runs runNoiseEvents in a separate worker so it does not block the main thread.
disp('Starting audio recording...');

testconvDuration = 60; % seconds (for testing)
numCycleEvents = 6;
convBlockDuration = 60*numCycleEvents; % for real experiment
totalDuration = convBlockDuration;
noiseFile = 'pink_noise_44k1.wav';

%% noise phase 1
noisePhase = p1;
% noiseFuture = parfeval(@runNoiseEvents, 0, totalDuration, numCycleEvents, targetDir, experimentID, playDeviceID1, playDeviceID2, noiseFile, noisePhase);
noiseTimer = timer('StartDelay', 1, 'TimerFcn', @(~,~) parfeval(@noiseRandnPTB, 0, totalDuration, numCycleEvents, experimentID, playDeviceID1, playDeviceID2, noiseLogDir, noiseFile, noisePhase));
start(noiseTimer);

%% Start conversation measurement
convStartTime = GetSecs;
disp('Conversational measurement started.');

while (GetSecs - convStartTime) < convBlockDuration
    frame2 = snapshot(cam2);
    frame2_mirror = fliplr(frame2);
    frame2 = uint8(frame2);
    texture2 = Screen('MakeTexture', winMain, frame2_mirror);
    Screen('DrawTexture', winMain, texture2, [], rectMain);
    DrawFormattedText(winMain, headerText, 'center', 30, whiteMain);
    Screen('Flip', winMain);
    Screen('Close', texture2);

    % For booth 1: Retrieve available audio samples from its recording channel.
    [audioData1, nSamples1] = PsychPortAudio('GetAudioData', recObjA3);
    if nSamples1 > 0
        audioData1 = audioData1(:).';
        buffer1 = [buffer1, audioData1];
    end

    % For booth 2:
    [audioData2, nSamples2] = PsychPortAudio('GetAudioData', recObjB3);
    if nSamples2 > 0
        audioData2 = audioData2(:).';
        buffer2 = [buffer2, audioData2];
    end

    % if terminated
    [keyIsDown, ~, keyCode] = KbCheck;
    if keyIsDown && any(keyCode(shiftKeys))
        disp('Conversational measurement terminated by experimenter.');
        break;
    end

    WaitSecs(pollInterval);

end

% wait(futNoise)

% noiseRandnPTB(measurementconvDuration, 6); % randomise the noise

PsychPortAudio('Stop', recObjA3);
PsychPortAudio('Stop', recObjB3);

stop(noiseTimer);

% PsychPortAudio('Stop', playHandle1, 1); 
% PsychPortAudio('Stop', playHandle2, 1); 

%% (Optional) Wait for the noise events to finish (if not already complete)
% 
filePathA = fullfile(targetDir, sprintf('p142_%s_3A_%s_n.wav', experimentID, noisePhase));
filePathB = fullfile(targetDir, sprintf('p142_%s_3B_%s_n.wav', experimentID, noisePhase));

audiowrite(filePathA, buffer1, fs_audio);
audiowrite(filePathB, buffer2, fs_audio);
disp('Audio recordings saved.');

PsychPortAudio('Close', recObjA3);
PsychPortAudio('Close', recObjB3);

disp('Audio recordings stopped.');

%% trigger sending for end
Eyelink('Message', 'END100'); 
WaitSecs(pollInterval); 
SendTrig(trigger_port, 255)
WaitSecs(1.0);         

%% Window 18: End of Conversation Measurement & Break
endConvText = ['Thank you for your participation in this part of the experiment.\n\n' ...
               'Please take a 3-minute break. You may stretch and relax.\n\n' ...
               'The experimenter will inform you when to proceed to the next step.'];

DrawFormattedText(winMain, endConvText, 'center', 'center', whiteMain);
Screen('Flip', winMain);
         
KbWaitForShift();
disp('Break ended. Proceeding to the next part.');

