%% posteriorRestingState.m
%
% This script implements the posterior baseline measurement of the experiment:
%
% Author: [Moana Chen]
% Date: [25.02.2025]

%% Window 1: Baseline Measurement (No Input) with focus Symbol
pollInterval = 0.01;
restText = ['Thank you for your active participation! \n\n' ...
            'Now we ask you to perform the baseline measurement again. \n\n' ...
            'Please sit still with no movements and keep looking at the + symbol on the screen centre silently, \n\n' ...
            'till the experimenter informs you of the next step. \n\n'];
DrawFormattedText(winMain, restText, 'center', 'center', whiteMain);
Screen('Flip', winMain)
KbWaitForShift();
WaitSecs(0.5);

[xCenter, yCenter] = RectCenter(rectMain); % 1
plusSize = 20;
Screen('DrawLine', winMain, whiteMain, xCenter - plusSize, yCenter, xCenter + plusSize, yCenter, 5);
Screen('DrawLine', winMain, whiteMain, xCenter, yCenter - plusSize, xCenter, yCenter + plusSize, 5);
targetTime = GetSecs + 0.1;
Screen('Flip', winMain, targetTime);

KbWaitForShift();

%% trigger sending for start
Eyelink('Message', ('REC100')); 
WaitSecs(pollInterval);
SendTrig(trigger_port, 100)


% Simulate EEG/ECG recording for 4 minutes with early termination option
KbName('UnifyKeyNames');
shiftKeys = [KbName('LeftShift'), KbName('RightShift')];
startTime = GetSecs;
disp('Baseline (no input) measurement started (4 minutes).');
while (GetSecs - startTime) < 240   % 240 seconds = 4 minutes
     [keyIsDown, ~, keyCode] = KbCheck;
     if keyIsDown && any(keyCode(shiftKeys))
         disp('Early termination of baseline (no input) measurement.');
         break;
     end
     WaitSecs(0.5);
end
targetTime = GetSecs + 0.1;    
DrawFormattedText(winMain, 'Baseline (no input) measurement complete.\n\n', 'center', 'center', whiteMain); % Press Shift to continue
Screen('Flip', winMain, targetTime);

%% trigger sending for end
Eyelink('Message', 'END100'); 
WaitSecs(pollInterval); 
SendTrig(trigger_port, 255)

KbWaitForShift();
WaitSecs(0.5);

disp('Baseline (no input) measurement ended.');

%% Window 2: Baseline Measurement (eye closed)
speakText = ['The we move on to perform the last baseline measurement.\n\n' ...
             'Please sit still with no movements and with eyes closed for 4 minutes.\n\n'];
targetTime = GetSecs + 0.1;
DrawFormattedText(winMain, speakText, 'center', 'center', whiteMain);
Screen('Flip', winMain, targetTime);
KbWaitForShift();

%% trigger sending for start
Eyelink('Message', ('REC100')); 
WaitSecs(pollInterval);
SendTrig(trigger_port, 100)

startTime = GetSecs;
disp('Baseline (eyes closed) measurement started (4 minutes).');
while (GetSecs - startTime) < 240   % 120 seconds = 2 minutes
     [keyIsDown, ~, keyCode] = KbCheck;
     if keyIsDown && any(keyCode(shiftKeys))
         disp('Early termination of spontaneous speaking measurement.');
         break;
     end
     WaitSecs(0.5);
end
targetTime = GetSecs + 0.1;    
DrawFormattedText(winMain, 'Resting state with eyes closed measurement complete.\n\n', 'center', 'center', whiteMain); % Press Shift to continue
Screen('Flip', winMain, targetTime);

KbWaitForShift();
%% trigger sending for end
Eyelink('Message', 'END100'); 
WaitSecs(pollInterval); 
SendTrig(trigger_port, 255)

disp('Baseline (eyes closed) measurement ended.');

clear cam2;
