%% Participant ID Input
% Put before loading the experiment window
% Author: [Moana Chen]
% Date: [25.02.2025]
prompt = {'Please enter the experimentID:'};
dlg_title = 'For Participants Identification';
num_lines = 1;
defaultans = {''};
answer = inputdlg(prompt, dlg_title, num_lines, defaultans);

if isempty(answer)
    error('experimentID entry cancelled.');
end

experimentID = answer{1};  % Use this ID to name your files later
fprintf('experimentID: %s\n', experimentID);

