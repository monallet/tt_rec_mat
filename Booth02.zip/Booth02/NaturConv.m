% NaturConv.m
%
% This script implements the natural conversation measurement for the experiment:
%
% Window 10: Conversation instructions and readiness confirmation.
% Optional if not included in the main script: Window 11: Calibration for the first 8-10 minutes.
% Window 12: Topic introduction – a 1-minute familiarisation window with the conversation topic.
% Window 13: Live conversation measurement with live video streaming of both participants' faces.
% Window 14: End of conversation measurement and a 3-minute break.
%
% Author: [Moana Chen]
% Date: [25.02.2025]

%% Window 10: Conversation Instructions & Participant Readiness
pollInterval = 0.01;
convInstr = ['Part 2: \n\n' ...
             'Now you are on part two of this experiment.\n\n' ...
             'Both of you will start a conversation for about 20 minutes on the given topic.\n' ...
             'Please keep your voice normal and keep your head and body still except for your articulatory organs.\n\n' ...
             'When both of you are ready, we will initiate recording on your conversation.'];

DrawFormattedText(winMain, convInstr, 'center', 'center', whiteMain);
Screen('Flip', winMain);

KbWaitForShift();
WaitSecs(0.5);

% For confirmation
expChoice = questdlg('Both participants are ready. Please confirm the beginning of the conversational measurement.', ...
                     'Experimenter Confirmation', ...
                     'Confirm', 'Cancel', 'Confirm');
if ~strcmp(expChoice, 'Confirm')
    error('Experimenter cancelled the measurement.');
end
WaitSecs(0.1);

%% Window 11: Calibration eyelink and close
% eyeCalib; % the first calibration for the NaturConv block
% calibrationStatus = waitForCalibrationAcceptance();
% if strcmp(calibrationStatus, 'accepted')
%     disp('Calibration done.');
%     WaitSecs(0.1);
% else
%     disp('Calibration failed.');
% end

%% Window 12: Topic Introduction (0.5-minute familiarisation)
topicText = ['Now you have 30 seconds to get familiar with the topic you are going to discuss:\n\n\n' ...
             '- You can start conversation on the quality of your daily life from different aspects, \n' ...
             'e.g., sleep, nutrition, work, partnership, hobby. \n\n' ...
             '- You can also share personal experiences that specifically changed the quality of your everyday life, \n' ...
             'such as how you overcame the difficulties in your daily life, e.g., nutritional problems, sleep, working habits etc. \n\n' ...
             '- Feel free to propose self-improvement techniques like meditation, sports, physical training, leisure, and travelling. \n\n\n' ...
             'This is just a proposal to initiate your conversation, you can always drift in other topics if it maintains your interest. \n' ...
             'You can also always go back to the initiated topics.\n\n' ...
             'You could begin with greeting and then proceed to the topics together.\n\n' ];

DrawFormattedText(winMain, topicText, 'center', 'center', whiteMain);
Screen('Flip', winMain);

% Wait up to 30 seconds or terminate early if Shift is pressed:
KbName('UnifyKeyNames');
shiftKeys = [KbName('LeftShift'), KbName('RightShift')];
startTime = GetSecs;
while (GetSecs - startTime) < 30
    [keyIsDown, ~, keyCode] = KbCheck;
    if keyIsDown && any(keyCode(shiftKeys))
        break;
    end
    WaitSecs(0.01);
end

%% Window 13: Live Conversation Measurement with Video Streaming
headerText = ['Conversational Measurement in Progress... \n\n' ...
              'You can start conversation on the quality of your daily life from different aspects,\n' ...
              'e.g., sleep, nutrition, work, partnership, hobby... \n' ...
              'And you can explore more topics during the talk with each other if it maintains your interest. \n\n'];


%% Create two audiorecorder objects using different device IDs.
recObjA2 = PsychPortAudio('Open', recordDeviceID1, 2, 1, fs_audio, nChannels, buffersize);
recObjB2 = PsychPortAudio('Open', recordDeviceID2, 2, 1, fs_audio, nChannels, buffersize);

KbWaitForShift();

eyeSave(targetDir, experimentID, phaseID);
Eyelink('StartRecording');

PsychPortAudio('GetAudioData', recObjA2, rec.amountToAllocateSecs);
PsychPortAudio('GetAudioData', recObjB2, rec.amountToAllocateSecs);

% two buffers to store the entire recordings
buffer1 = []; % for booth 1 microphone
buffer2 = []; % for booth 2 microphone

% initilise the recording
PsychPortAudio('Start', recObjA2, rec.repetitions, rec.when, rec.waitForStart);
PsychPortAudio('Start', recObjB2, rec.repetitions, rec.when, rec.waitForStart);
disp('Starting audio recording...');

%% trigger sending for start
Eyelink('Message', ('REC100')); 
WaitSecs(pollInterval);
SendTrig(trigger_port, 100)

% Start conversation measurement
convStartTime = GetSecs;
disp('Conversational measurement started.');

videoPath = fullfile(targetDir, sprintf('p142_%s_2B_a.avi', experimentID));
videoObj = VideoWriter(videoPath);
videoObj.FrameRate = 25; % desired frame rate, must match the recorders'
open(videoObj);

%% camera and audio recording loop
convBlockDurationA = 60*10;
while (GetSecs - convStartTime) < convBlockDurationA
    frame2 = snapshot(cam2);
    frame2_mirror = fliplr(frame2);
    frame2 = uint8(frame2);

    writeVideo(videoObj, frame2_mirror);

    texture2 = Screen('MakeTexture', winMain, frame2_mirror);
    Screen('DrawTexture', winMain, texture2, [], rectMain);
    DrawFormattedText(winMain, headerText, 'center', 30, whiteMain);        

    Screen('Flip', winMain);
    Screen('Close', texture2);

    % For booth 1: 
    [audioData1, nSamples1] = PsychPortAudio('GetAudioData', recObjA2);
    if nSamples1 > 0
        audioData1 = audioData1(:).';
        buffer1 = [buffer1, audioData1];
    end
    
    % For booth 2: 
    [audioData2, nSamples2] = PsychPortAudio('GetAudioData', recObjB2);
    if nSamples2 > 0
        audioData2 = audioData2(:).';
        buffer2 = [buffer2, audioData2];
    end

    [keyIsDown, ~, keyCode] = KbCheck;
    if keyIsDown && any(keyCode(shiftKeys))
        disp('Conversational measurement block A terminated by experimenter.');
        break;
    end
    WaitSecs(pollInterval);
end

%% Drift correction after the first 10 minutes
SendTrig(trigger_port, 200);
Eyelink('Message','!V DRIFT_CORRECTIN');

close(videoObj);

% Guidance on-screen
calibText = ['We can have a short break and the re-calibration/drift correction will shortly start.\n\n' ...
             'Please wait quietly and still until the focus points show on the screen.'];
DrawFormattedText(winMain, calibText, 'center', 'center', whiteMain);
Screen('Flip', winMain);
KbWaitForShift();

WaitSecs(0.1);
EyelinkDoDriftCorrect(el);  
WaitSecs(0.1); 
Eyelink('Message','!V DRIFT_CORRECTED');

WaitSecs(0.1);
SendTrig(trigger_port, 201);
Eyelink('Message','REC201');

%% camera open again
videoPath = fullfile(targetDir, sprintf('p142_%s_2B_b.avi', experimentID)); % overwrite the video object
videoObj = VideoWriter(videoPath);
videoObj.FrameRate = 25; % desired frame rate, must match the recorders'
open(videoObj);

convBlockDurationB = 60*10;
while (GetSecs - convStartTime) < convBlockDurationB
    frame2 = snapshot(cam2);
    frame2_mirror = fliplr(frame2);
    frame2 = uint8(frame2);

    writeVideo(videoObj, frame2_mirror);

    texture2 = Screen('MakeTexture', winMain, frame2_mirror);
    Screen('DrawTexture', winMain, texture2, [], rectMain);
    
    DrawFormattedText(winMain, headerText, 'center', 30, whiteMain);        

    Screen('Flip', winMain);
    Screen('Close', texture2);

    % For booth 1: 
    [audioData1, nSamples1] = PsychPortAudio('GetAudioData', recObjA2);
    if nSamples1 > 0
        audioData1 = audioData1(:).';
        buffer1 = [buffer1, audioData1];
    end
    
    % For booth 2: 
    [audioData2, nSamples2] = PsychPortAudio('GetAudioData', recObjB2);
    if nSamples2 > 0
        audioData2 = audioData2(:).';
        buffer2 = [buffer2, audioData2];
    end

WaitSecs(pollInterval);
    [keyIsDown, ~, keyCode] = KbCheck;
    if keyIsDown && any(keyCode(shiftKeys))
        disp('Conversational measurement block B terminated by experimenter.');
        break;
    end
    WaitSecs(pollInterval);
end

% Stop both recordings.
close(videoObj);
disp('Video recording saved.');

PsychPortAudio('Stop', recObjA2);
PsychPortAudio('Stop', recObjB2);
disp('Audio recordings stopped.');

filePathA = fullfile(targetDir, sprintf('p142_%s_2A.wav', experimentID));
filePathB = fullfile(targetDir, sprintf('p142_%s_2B.wav', experimentID));
audiowrite(filePathA, buffer1, fs_audio);
audiowrite(filePathB, buffer2, fs_audio);
disp('Audio recordings saved.');

PsychPortAudio('Close', recObjA2);
PsychPortAudio('Close', recObjB2);


%% trigger sending for end
Eyelink('Message', 'END100'); 
WaitSecs(pollInterval); 
SendTrig(trigger_port, 255)
WaitSecs(1.0);

%% Window 14: End of Conversation Measurement & Break
endConvText = ['Thank you for your participation in this part of the experiment.\n\n' ...
               'Please take a 3-minute break. You may stretch and relax.\n\n' ...
               'The experimenter will inform you when to proceed to the next step.'];

DrawFormattedText(winMain, endConvText, 'center', 'center', whiteMain);
Screen('Flip', winMain);
         
KbWaitForShift();
disp('Break ended. Proceeding to the next part.');
