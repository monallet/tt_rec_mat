%% Local Function buildFullTimeline
% Author: [Moana Chen]
% Date: [25.02.2025]
function fullResponses = buildFullTimeline(syncIntervals, audioDuration)
    % Converts syncIntervals (rows [start, end]) into a full timeline
    % including 'out' intervals.
    
    fullResponses = {};
    fullIdx = 1;
    lastTime = 0;
    
    for i = 1:size(syncIntervals,1)
        startSync = syncIntervals(i,1);
        endSync   = syncIntervals(i,2);
        if startSync > lastTime
            % out interval
            fullResponses{fullIdx,1} = lastTime;
            fullResponses{fullIdx,2} = startSync;
            fullResponses{fullIdx,3} = 'out';
            fullIdx = fullIdx + 1;
        end
        % sync interval
        fullResponses{fullIdx,1} = startSync;
        fullResponses{fullIdx,2} = endSync;
        fullResponses{fullIdx,3} = 'sync';
        fullIdx = fullIdx + 1;
        lastTime = endSync;
    end
    
    % If leftover time
    if lastTime < audioDuration
        fullResponses{fullIdx,1} = lastTime;
        fullResponses{fullIdx,2} = audioDuration;
        fullResponses{fullIdx,3} = 'out';
    end
end
