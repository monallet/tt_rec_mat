% MainExperiment_Part4.m
%
% This script implements Windows 24-26 of the experiment:
%
% Window 16: Questionnaire instructions with a simulated "Next" button.
% Window 17: Questionnaire page placeholder.
% Window 18: Final thank-you message.
%
% Author: [Moana Chen]
% Date: [25.02.2025]    

%% Window 24: Questionnaire Instructions
questionnaireInstr = ['Thank you again for your active participation! \n\n' ...
                      'Now we have a short questionnaire about our study for you to answer. \n' ...
                      'You can take your time and stretch yourself during the questionnaire. \n\n' ...
                      'Press any key to continue.'];

DrawFormattedText(winMain, questionnaireInstr, 'center', 'center', whiteMain);
% DrawFormattedText(winExt, questionnaireInstr, 'center', 'center', whiteExt);    
Screen('Flip', winMain);
% Screen('Flip', winExt);    
            
KbWaitForShift();  % Wait for any key press

%% Window 25: Questionnaire Page Placeholder
questionnaireText = ['[Questionnaire Page]\n\n' ...
                     '(This is a placeholder for the interactive questionnaire.)\n' ...
                     'Please complete the questionnaire and then press any key to continue.'];

DrawFormattedText(winMain, questionnaireText, 'center', 'center', whiteMain);
% DrawFormattedText(winExt, questionnaireText, 'center', 'center', whiteExt);    
Screen('Flip', winMain);
% Screen('Flip', winExt);   

KbWaitForShift();  % Wait for any key press

%% Window 26: Final Thank-You Message
finalText = ['Thank you so much for your participation.\n\n' ...
             'Please stay in the booth and wait for the experimenter to remove the equipments.'];

DrawFormattedText(winMain, finalText, 'center', 'center', whiteMain);
% DrawFormattedText(winExt, finalText, 'center', 'center', whiteExt);    
Screen('Flip', winMain);
% Screen('Flip', winExt);
