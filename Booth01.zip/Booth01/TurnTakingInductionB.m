%% TurnTakingInductionB.m
%
% This script implements the joint task B for the experiment:
%
% Window 6: Joint counting task instructions.
% Window 7: Waiting for the other speaker and experimenter confirmation.
% Window 8: Joint counting measurement with live video (using the web camera).
%
% Author: [Moana Chen]
% Date: [25.02.2025]

%% Window 6: Joint Counting Task Instructions
pollInterval = 0.01;
jointCountText2 = ['You and your partner are now being assigned with the second joint counting task.\n\n' ...
                   'You may cooperate with your partner to count from 1 to 100 to 0, one step at a time.\n\n' ...
                   'Please try to keep your voice normal and the counting pace constant.\n\n' ...
                   'When you are ready, please press the button on your right hand and wait for your partner.'];
DrawFormattedText(winMain, jointCountText2, 'center', 'center', whiteMain);
Screen('Flip', winMain);

KbWaitForShift();
WaitSecs(0.5);  
 
%% Window 7: Waiting for Experimenter Confirmation
waitingText = ['Waiting for the other speaker...\n\n' ...
               'Once both participants are ready, the experimenter will confirm the start of measurement.'];

DrawFormattedText(winMain, waitingText, 'center', 'center', whiteMain);
Screen('Flip', winMain);

expChoice = questdlg('Both participants are ready. Please confirm the beginning of the joint counting measurement.', ...
                     'Experimenter Confirmation', 'Confirm', 'Cancel', 'Confirm');
if ~strcmp(expChoice, 'Confirm')
    error('Experimenter cancelled the measurement.');
end
WaitSecs(0.5);

%% Window 8: Joint Counting Measurement with Video Streaming & Audio Recording
headerText = 'Joint Counting Measurement in Progress...';
 
recObjA1 = PsychPortAudio('Open', recordDeviceID1, 2, 1, fs_audio, nChannels, buffersize);
recObjB1 = PsychPortAudio('Open', recordDeviceID2, 2, 1, fs_audio, nChannels, buffersize);

PsychPortAudio('GetAudioData', recObjA1, rec.amountToAllocateSecs);
PsychPortAudio('GetAudioData', recObjB1, rec.amountToAllocateSecs);

buffer1 = []; % for booth 1 microphone
buffer2 = []; % for booth 2 microphone

PsychPortAudio('Start', recObjA1, rec.repetitions, rec.when, rec.waitForStart);
PsychPortAudio('Start', recObjB1, rec.repetitions,rec.when, rec.waitForStart);

%% trigger sending for start
Eyelink('Message', ('REC100')); 
WaitSecs(pollInterval);
SendTrig(trigger_port, 100)


disp('Starting audio recording for joint counting measurement...'); 

%% Start the joint counting measurement
measurementDurationF0 = 900;  % limit set
jointStartTime = GetSecs;
disp('Joint counting measurement started.');

KbName('UnifyKeyNames');
shiftKeys = [KbName('LeftShift'), KbName('RightShift')];

while (GetSecs - jointStartTime) < measurementDurationF0
    frame2 = snapshot(cam2);
    frame2_mirror = fliplr(frame2);
    frame2 = uint8(frame2);
    texture2 = Screen('MakeTexture', winMain, frame2_mirror);
    Screen('DrawTexture', winMain, texture2, [], rectMain);
    DrawFormattedText(winMain, headerText, 'center', 30, whiteMain);
    Screen('Flip', winMain);
    Screen('Close', texture2);
    
    % For booth 1: retrieve available audio samples from its recording channel.
    [audioData1, nSamples1] = PsychPortAudio('GetAudioData', recObjA1);
    if nSamples1 > 0
        audioData1 = audioData1(:).';
        buffer1 = [buffer1, audioData1];
    end
    
    % For booth 2: 
    [audioData2, nSamples2] = PsychPortAudio('GetAudioData', recObjB1);
    if nSamples2 > 0
        audioData2 = audioData2(:).';
        buffer2 = [buffer2, audioData2];
    end
    
    KbName('UnifyKeyNames');
    shiftKeys = [KbName('LeftShift'), KbName('RightShift')];
    [keyIsDown, ~, keyCode] = KbCheck;
    if keyIsDown && any(keyCode(shiftKeys))
         disp('Joint counting measurement terminated early by experimenter.');
         break;
    end
    
    WaitSecs(pollInterval);
end

PsychPortAudio('Stop', recObjA1);
PsychPortAudio('Stop', recObjB1);

disp('Audio recordings stopped.');

filePathA = fullfile(targetDir, sprintf('p142_%s_1A_b.wav', experimentID));
filePathB = fullfile(targetDir, sprintf('p142_%s_1B_b.wav', experimentID));

audiowrite(filePathA, buffer1, fs_audio);
audiowrite(filePathB, buffer2, fs_audio);

PsychPortAudio('Close', recObjA1);
PsychPortAudio('Close', recObjB1);



%% trigger sending for end
Eyelink('Message', 'END100'); 
WaitSecs(pollInterval); 
SendTrig(trigger_port, 255)

disp('Audio recordings saved.');
