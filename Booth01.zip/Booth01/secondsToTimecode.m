%% Local Function secondsToTimecode
% Author: [Moana Chen]
% Date: [25.02.2025]
function timecode = secondsToTimecode(secondsVal, frameRate)
    hours = floor(secondsVal / 3600);
    minutes = floor(mod(secondsVal, 3600) / 60);
    secs = floor(mod(secondsVal, 60));
    frames = floor((secondsVal - floor(secondsVal)) * frameRate);
    timecode = sprintf('%02d:%02d:%02d:%02d', hours, minutes, secs, frames);
end