function syncResponses = recordSelfEvalResponsesAndDrawDual(win, xVals, yVals1, yVals2, playbackStartTime, audioDuration, keyName, color1, color2)
    % This function polls for a specific key press during audio playback while
    % dynamically drawing two waveforms (one in color1, one in color2) at two vertical positions,
    % and drawing a common playhead (vertical black bar) that spans the region between them.
    % It returns a cell array of sync intervals (in seconds relative to playbackStartTime).
    % Author: [Moana Chen]
    % Date: [25.03.2025]
    
    pollInterval = 0.01;
    KbName('UnifyKeyNames');
    targetKeyCode = KbName(keyName);
    
    syncIntervals = [];
    responseIdx = 1;
    wasPressed = false;
    currentIntervalStart = [];
    
    t0 = playbackStartTime;
    while (GetSecs - t0) < audioDuration
        elapsed = GetSecs - t0;
        
        % Poll for the designated key press:
        [keyIsDown, keyTime, keyCode] = KbCheck;
        if keyIsDown && keyCode(targetKeyCode)
            if ~wasPressed
                wasPressed = true;
                currentIntervalStart = keyTime;
            end
        else
            if wasPressed
                wasPressed = false;
                syncIntervals(responseIdx,:) = [currentIntervalStart, GetSecs];
                responseIdx = responseIdx + 1;
            end
        end
        
        % Draw the dynamic display:
        Screen('FillRect', win, [255,255,255]);  % Clear window with white
        
        % Draw the two waveforms with specified colors:
        drawWaveform(win, xVals, yVals1, color1);
        drawWaveform(win, xVals, yVals2, color2);
        
        % Draw header text (optional)
        headerText = 'How smooth is the speaker transition?';
        Screen('TextSize', win, 24);
        DrawFormattedText(win, headerText, 'center', 50, [0,0,0]);
        
        % Compute the current playhead x-position:
        fraction = elapsed / audioDuration;
        xPlayhead = xVals(1) + fraction * (xVals(end) - xVals(1));
        
        % Determine vertical span: from just above the upper waveform to just below the lower.
        yTop = min([min(yVals1), min(yVals2)]) - 10;
        yBottom = max([max(yVals1), max(yVals2)]) + 10;
        playheadWidth = 2;
        rectPlayhead = [xPlayhead - playheadWidth/2, yTop, xPlayhead + playheadWidth/2, yBottom];
        Screen('FillRect', win, [0,0,0], rectPlayhead);
        
        Screen('Flip', win);
        WaitSecs(pollInterval);
    end
    
    % If key was still pressed at the end, close the final interval:
    if wasPressed
        syncIntervals(responseIdx,:) = [currentIntervalStart, t0 + audioDuration];
    end
    
    % Convert absolute timestamps to times relative to playbackStartTime.
    if ~isempty(syncIntervals)
        syncIntervals = syncIntervals - t0;
    end
    
    % Build a complete timeline including 'sync' and 'out' intervals.
    syncResponses = buildFullTimeline(syncIntervals, audioDuration);
end