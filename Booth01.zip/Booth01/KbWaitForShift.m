%% Local Function: KbWaitForShift
function KbWaitForShift()
    % KbWaitForShift waits until the user presses either LeftShift or RightShift.
    KbName('UnifyKeyNames');
    shiftKeys = [KbName('LeftShift'), KbName('RightShift')];
    while true
        [keyIsDown, ~, keyCode] = KbCheck;
        if keyIsDown && any(keyCode(shiftKeys))
            break;
        end
    end
    WaitSecs(0.2);  % Debounce delay
end