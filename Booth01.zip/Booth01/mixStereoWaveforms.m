% Author: [Jin Liu, Moana Chen]
% Date: [25.02.2025]
function mixed = mixStereoWaveforms(y1, y2)
    % This function mixes two audio waveforms and ensures the result is at -23 dB
    % Handles both mono and stereo inputs
    % Inputs:
    %   y1 - First audio waveform (samples x channels) already at ~-23 dB
    %   y2 - Second audio waveform (samples x channels) already at ~-23 dB
    % Output:
    %   mixed - Mixed audio waveform also at -23 dB
    
    % Check if inputs are mono or stereo
    y1_is_mono = (size(y1, 2) == 1);
    y2_is_mono = (size(y2, 2) == 1);
    
    % Convert mono to stereo if needed
    if y1_is_mono && ~y2_is_mono
        y1 = [y1, y1];
    elseif ~y1_is_mono && y2_is_mono
        y2 = [y2, y2];
    end
    
    % Match format
    num_channels = size(y1, 2);
    
    % Match lengths
    len1 = size(y1, 1);
    len2 = size(y2, 1);
    
    if len1 > len2
        y2 = [y2; zeros(len1 - len2, num_channels)];
    elseif len2 > len1
        y1 = [y1; zeros(len2 - len1, num_channels)];
    end
    
    % Mix the waveforms with simple addition
    mixed = (y1 + y2);
    
    % Target level: -26 dB corresponds to RMS of ~0.07079
%     target_level = 0.0562;  % Target level: -25 dB 
%     target_level = 0.0501;  % Target level: -26 dB
%      target_level = 0.0447;  % Target level: -27 dB
%      target_level = 0.0398;  % Target level: -28 dB
%       target_level = 0.0350; 
%       target_level = 0.0340; 
%       target_level = 0.0300; 
      target_level = 0.0280; 

    
    % Adjust the mixed result to target -23 dB
    for ch = 1:num_channels
        current_rms = sqrt(mean(mixed(:,ch).^2));
        
        if current_rms > 0
            mixed(:,ch) = mixed(:,ch) * (target_level / current_rms);
        end
    end
end