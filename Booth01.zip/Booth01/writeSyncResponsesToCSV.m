%% Local Function writeSyncResponsesToCSV
% Author: [Moana Chen]
% Date: [25.02.2025]
function writeSyncResponsesToCSV(syncResponses, csvFilename)
    frameRate = 24;
    fid = fopen(csvFilename, 'w');
    if fid == -1
        error('Cannot open file: %s', csvFilename);
    end
    
    for i = 1:size(syncResponses,1)
        startSec = syncResponses{i,1};
        endSec   = syncResponses{i,2};
        state    = syncResponses{i,3};
        startCode = secondsToTimecode(startSec, frameRate);
        endCode   = secondsToTimecode(endSec, frameRate);
        fprintf(fid, '%s-%s, %s\n', startCode, endCode, state);
    end
    fclose(fid);
    disp(['Self-evaluation responses saved to ', csvFilename]);
end