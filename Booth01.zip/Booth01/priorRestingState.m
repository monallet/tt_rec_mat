%% priorRestingState.m
%
% This script implements the prior baseline measurement of the experiment:
%
% Window 1: Welcome and general instruction.
% Window 2: Baseline measurement (no input) with a fixation '+'.
% Window 3: Baseline measurement (eyes closed).
% Window 4: Baseline measurement (acoustic).
% Window 5: Baseline measurement (visual input) with live video streaming.
% Window 6: A 2-minute break.
% For the whole experiment, the proceding of nachst blocks and early termination during the simulated recording periods is enabled via a Shift-key press.
%
% Author: [Moana Chen]
% Date: [25.02.2025]

%% Window 1: Welcome Page
pollInterval = 0.01;
welcomeText = ['The experiment will contain three parts generally: conversations, joint task, and self-evaluation.\n\n' ...
               'The experiment will shortly begin, please wait for the experimenter initiating the measurement.'];

targetTime = GetSecs + 0.1;
DrawFormattedText(winMain, welcomeText, 'center', 'center', whiteMain);
Screen('Flip', winMain, targetTime);
% Wait for experimenter confirmation
KbWaitForShift();
WaitSecs(0.1);

%% Window 2: Baseline Measurement (No Input) with Focus Symbol
restText = ['You are now asked to perform a baseline measurement.\n\n' ...
            'Please sit still with no movements and keep looking at the + symbol on the screen centre silently,\n\n' ...
            'till the experimenter informs you of the next step.\n\n'];
DrawFormattedText(winMain, restText, 'center', 'center', whiteMain);
Screen('Flip', winMain)
KbWaitForShift();
WaitSecs(0.1);

% Draw the fixation sign in the center
[xCenter, yCenter] = RectCenter(rectMain); % 1
plusSize = 20;
Screen('DrawLine', winMain, whiteMain, xCenter - plusSize, yCenter, xCenter + plusSize, yCenter, 5);
Screen('DrawLine', winMain, whiteMain, xCenter, yCenter - plusSize, xCenter, yCenter + plusSize, 5);
targetTime = GetSecs + 0.1;
Screen('Flip', winMain, targetTime);

%% trigger sending for start
Eyelink('Message', ('REC100')); 
WaitSecs(pollInterval);
SendTrig(trigger_port, 100)

%% Simulate EEG/ECG recording for 4 minutes with early termination option
KbName('UnifyKeyNames');
shiftKeys = [KbName('LeftShift'), KbName('RightShift')];
startTime = GetSecs;
disp('Baseline (no input) measurement started (4 minutes).');
while (GetSecs - startTime) < 240   % 240 seconds = 4 minutes
     [keyIsDown, ~, keyCode] = KbCheck;
     if keyIsDown && any(keyCode(shiftKeys))
         disp('Early termination of baseline (no input) measurement.');
         break;
     end
     WaitSecs(0.1);
end
targetTime = GetSecs + 0.1;    
DrawFormattedText(winMain, 'Baseline (no input) measurement complete.\n\n', 'center', 'center', whiteMain); % Press Shift to continue
Screen('Flip', winMain, targetTime);

KbWaitForShift();
WaitSecs(0.1);

%% trigger sending for end
Eyelink('Message', 'END100'); 
WaitSecs(pollInterval); 
SendTrig(trigger_port, 255)

disp('Baseline (no input) measurement ended.');

%% Window 3: Baseline Measurement (eye closed)
speakText = ['You are now asked to perform another baseline measurement.\n\n' ...
             'Please sit still with no movements and with eyes closed for 4 minutes,\n\n' ...
             'till the experimenter informs you of the next step.\n\n'];
targetTime = GetSecs + 0.1;    
DrawFormattedText(winMain, speakText, 'center', 'center', whiteMain);
Screen('Flip', winMain, targetTime);
KbWaitForShift();

%% trigger sending for start
Eyelink('Message', ('REC100')); 
WaitSecs(pollInterval);
SendTrig(trigger_port, 100)

%%
startTime = GetSecs;
disp('Baseline (eyes closed) measurement started (4 minutes).');
while (GetSecs - startTime) < 240
    [xCenter, yCenter] = RectCenter(rectMain); % 1
    plusSize = 20;
    Screen('DrawLine', winMain, whiteMain, xCenter - plusSize, yCenter, xCenter + plusSize, yCenter, 5);
    Screen('DrawLine', winMain, whiteMain, xCenter, yCenter - plusSize, xCenter, yCenter + plusSize, 5);
    Screen('Flip', winMain);
    [keyIsDown, ~, keyCode] = KbCheck;
    if keyIsDown && any(keyCode(shiftKeys))
     disp('Early termination of baseline (eyes closed) measurement.');
     break;
    end
    WaitSecs(0.1);
end
targetTime = GetSecs + 0.1;    
DrawFormattedText(winMain, 'Resting state with eyes closed measurement complete.\n\n', 'center', 'center', whiteMain);
Screen('Flip', winMain, targetTime);

KbWaitForShift();

%% trigger sending for end
Eyelink('Message', 'END100'); 
WaitSecs(pollInterval); 
SendTrig(trigger_port, 255)

disp('Baseline (eyes closed) measurement ended.');

%% Window 4: Baseline Measurement (acoustic noise)
speakText = ['You are now asked to perform another baseline measurement.\n\n' ...
             'You will hear some noise for 2 minutes.\n\n' ...
             'Please sit still with no movements and with eyes open for 2 minutes,\n\n' ...
             'till the experimenter informs you of the next step.\n\n'];
targetTime = GetSecs + 0.1;    
DrawFormattedText(winMain, speakText, 'center', 'center', whiteMain);
Screen('Flip', winMain, targetTime);
KbWaitForShift();

%% trigger sending for start
Eyelink('Message', ('REC100')); 
WaitSecs(pollInterval);
SendTrig(trigger_port, 100)

%%
startTime = GetSecs;
disp('Baseline (acoustic noise) measurement started (2 minutes).');
noiseduration = 120; 
while (GetSecs - startTime) < noiseduration   % 120 seconds = 2 minutes
    resting_state_high_noise(65, 20);
    
    [xCenter, yCenter] = RectCenter(rectMain); % 1
    plusSize = 20;
    Screen('DrawLine', winMain, whiteMain, xCenter - plusSize, yCenter, xCenter + plusSize, yCenter, 5);
    Screen('DrawLine', winMain, whiteMain, xCenter, yCenter - plusSize, xCenter, yCenter + plusSize, 5);
    Screen('Flip', winMain);

    [keyIsDown, ~, keyCode] = KbCheck;
    if keyIsDown && any(keyCode(shiftKeys))
     disp('Early termination of baseline (acoustic noise) measurement.');
     break;
    end
    WaitSecs(0.1);
end

PsychPortAudio('Stop', playHandle1);
PsychPortAudio('Stop', playHandle2);
PsychPortAudio('Close', playHandle1);
PsychPortAudio('Close', playHandle2);

targetTime = GetSecs + 0.1;
DrawFormattedText(winMain, 'Resting state with acoustic noise measurement complete.\n\n', 'center', 'center', whiteMain); 
Screen('Flip', winMain, targetTime); 

KbWaitForShift();
%% trigger sending for end
Eyelink('Message', 'END100'); 
WaitSecs(pollInterval); 
SendTrig(trigger_port, 255)

disp('Baseline (acoustic noise) measurement ended.');

%% Window 5: Baseline Measurement (Visual Input with video streaming)
visualText = ['You are now asked to perform the last baseline measurement.\n\n' ...
              'There will be the face of your partner shown on the screen.\n\n' ...
              'Please sit still with no movements and keep looking at the face on screen,\n\n' ...
              'till the experimenter informs you of the next step.\n\n'];
targetTime = GetSecs + 0.1;        
DrawFormattedText(winMain, visualText, 'center', 'center', whiteMain);
Screen('Flip', winMain, targetTime);
KbWaitForShift();

%% trigger sending for start
Eyelink('Message', ('REC100')); 
WaitSecs(pollInterval);
SendTrig(trigger_port, 100)

%% Start live video streaming as visual input for 4 minutes (or until early termination)
disp('Baseline (visual input) measurement started (3 minutes).');
startTime = GetSecs;

while (GetSecs - startTime) < 180
     frame2 = snapshot(cam2);
     frame2_mirror = fliplr(frame2);
     frame2 = uint8(frame2);
     texture2 = Screen('MakeTexture', winMain, frame2_mirror);
     Screen('DrawTexture', winMain, texture2, [], rectMain);
     Screen('Flip', winMain);
     Screen('Close', texture2);
     
     [keyIsDown, ~, keyCode] = KbCheck;
     if keyIsDown && any(keyCode(shiftKeys))
         disp('Early termination of visual input measurement.');
         break;
     end
     WaitSecs(0.05);
end

targetTime = GetSecs + 0.1;        
DrawFormattedText(winMain, 'Visual input measurement complete.\n\n', 'center', 'center', whiteMain);
Screen('Flip', winMain, targetTime);
KbWaitForShift();

%% trigger sending for end
Eyelink('Message', 'END100'); 
WaitSecs(pollInterval); 
SendTrig(trigger_port, 255)

disp('Baseline (visual input) measurement ended.');

%% Window 5: Break
breakText = ['Please take a 2-minute break and you may slightly stretch your body during the break.\n\n' ...
             'The first task will be assigned to you shortly after.'];
targetTime = GetSecs + 0.1;        
DrawFormattedText(winMain, breakText, 'center', 'center', whiteMain);
Screen('Flip', winMain, targetTime);

KbWaitForShift();
disp('Break ended. Moving to the next part of the experiment.');
